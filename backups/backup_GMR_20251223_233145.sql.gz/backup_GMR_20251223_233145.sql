-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: GMR
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts_profiloutente`
--

DROP TABLE IF EXISTS `accounts_profiloutente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts_profiloutente` (
  `user_id` int(11) NOT NULL,
  `ruolo` varchar(20) NOT NULL,
  `dipartimento` varchar(100) DEFAULT NULL,
  `numero_dipendente` varchar(20) DEFAULT NULL,
  `attivo` tinyint(1) NOT NULL,
  `ultimo_accesso` datetime(6) DEFAULT NULL,
  `data_creazione` datetime(6) NOT NULL,
  `data_modifica` datetime(6) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `numero_dipendente` (`numero_dipendente`),
  CONSTRAINT `accounts_profiloutente_user_id_40d4a398_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_profiloutente`
--

LOCK TABLES `accounts_profiloutente` WRITE;
/*!40000 ALTER TABLE `accounts_profiloutente` DISABLE KEYS */;
INSERT INTO `accounts_profiloutente` (`user_id`, `ruolo`, `dipartimento`, `numero_dipendente`, `attivo`, `ultimo_accesso`, `data_creazione`, `data_modifica`) VALUES (1,'ADMIN','Squadra anti sommossa','1',1,'2025-12-23 22:05:17.989023','2025-11-30 19:48:58.269004','2025-12-23 22:05:17.989030'),(2,'OPERATORE','',NULL,1,'2025-12-05 21:44:50.093172','2025-11-30 19:51:08.305915','2025-12-05 21:44:50.093177'),(3,'OPERATORE',NULL,NULL,1,'2025-11-30 19:51:08.310102','2025-11-30 19:51:08.309844','2025-11-30 19:51:08.310105'),(4,'VISUALIZZATORE','',NULL,1,'2025-12-07 20:01:24.116537','2025-11-30 19:51:08.316623','2025-12-07 20:01:24.116545'),(5,'ADMIN',NULL,NULL,1,'2025-12-22 23:33:57.771922','2025-11-30 21:14:34.187172','2025-12-22 23:33:57.771933'),(6,'OPERATORE','',NULL,1,'2025-12-05 21:59:52.734693','2025-12-05 21:59:52.713215','2025-12-05 21:59:52.734701');
/*!40000 ALTER TABLE `accounts_profiloutente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add Profilo Utente',7,'add_profiloutente'),(26,'Can change Profilo Utente',7,'change_profiloutente'),(27,'Can delete Profilo Utente',7,'delete_profiloutente'),(28,'Can view Profilo Utente',7,'view_profiloutente'),(29,'Can add Log Accesso',8,'add_logaccesso'),(30,'Can change Log Accesso',8,'change_logaccesso'),(31,'Can delete Log Accesso',8,'delete_logaccesso'),(32,'Can view Log Accesso',8,'view_logaccesso'),(33,'Can add Categoria',9,'add_categoria'),(34,'Can change Categoria',9,'change_categoria'),(35,'Can delete Categoria',9,'delete_categoria'),(36,'Can view Categoria',9,'view_categoria'),(37,'Can add Unit?? di Misura',10,'add_unitamisura'),(38,'Can change Unit?? di Misura',10,'change_unitamisura'),(39,'Can delete Unit?? di Misura',10,'delete_unitamisura'),(40,'Can view Unit?? di Misura',10,'view_unitamisura'),(41,'Can add Fornitore',11,'add_fornitore'),(42,'Can change Fornitore',11,'change_fornitore'),(43,'Can delete Fornitore',11,'delete_fornitore'),(44,'Can view Fornitore',11,'view_fornitore'),(45,'Can add Pezzo di Ricambio',12,'add_pezzoricambio'),(46,'Can change Pezzo di Ricambio',12,'change_pezzoricambio'),(47,'Can delete Pezzo di Ricambio',12,'delete_pezzoricambio'),(48,'Can view Pezzo di Ricambio',12,'view_pezzoricambio'),(49,'Can add Giacenza',13,'add_giacenza'),(50,'Can change Giacenza',13,'change_giacenza'),(51,'Can delete Giacenza',13,'delete_giacenza'),(52,'Can view Giacenza',13,'view_giacenza'),(53,'Can add Movimento Magazzino',14,'add_movimentomagazzino'),(54,'Can change Movimento Magazzino',14,'change_movimentomagazzino'),(55,'Can delete Movimento Magazzino',14,'delete_movimentomagazzino'),(56,'Can view Movimento Magazzino',14,'view_movimentomagazzino'),(57,'Can add Inventario',15,'add_inventario'),(58,'Can change Inventario',15,'change_inventario'),(59,'Can delete Inventario',15,'delete_inventario'),(60,'Can view Inventario',15,'view_inventario'),(61,'Can add Dettaglio Inventario',16,'add_dettaglioinventario'),(62,'Can change Dettaglio Inventario',16,'change_dettaglioinventario'),(63,'Can delete Dettaglio Inventario',16,'delete_dettaglioinventario'),(64,'Can view Dettaglio Inventario',16,'view_dettaglioinventario'),(65,'Can add Documento Allegato',17,'add_documentoallegato'),(66,'Can change Documento Allegato',17,'change_documentoallegato'),(67,'Can delete Documento Allegato',17,'delete_documentoallegato'),(68,'Can view Documento Allegato',17,'view_documentoallegato'),(69,'Can add Configurazione',18,'add_configurazione'),(70,'Can change Configurazione',18,'change_configurazione'),(71,'Can delete Configurazione',18,'delete_configurazione'),(72,'Can view Configurazione',18,'view_configurazione'),(73,'Can add Azione Utente',19,'add_azioneutente'),(74,'Can change Azione Utente',19,'change_azioneutente'),(75,'Can delete Azione Utente',19,'delete_azioneutente'),(76,'Can view Azione Utente',19,'view_azioneutente'),(77,'Can add Matricola Macchina SCM',20,'add_matricolamacchinascm'),(78,'Can change Matricola Macchina SCM',20,'change_matricolamacchinascm'),(79,'Can delete Matricola Macchina SCM',20,'delete_matricolamacchinascm'),(80,'Can view Matricola Macchina SCM',20,'view_matricolamacchinascm'),(81,'Can add Modello Macchina SCM',21,'add_modellomacchinascm'),(82,'Can change Modello Macchina SCM',21,'change_modellomacchinascm'),(83,'Can delete Modello Macchina SCM',21,'delete_modellomacchinascm'),(84,'Can view Modello Macchina SCM',21,'view_modellomacchinascm'),(85,'Can add Unit?? di Misura',22,'add_tbunitamisura'),(86,'Can change Unit?? di Misura',22,'change_tbunitamisura'),(87,'Can delete Unit?? di Misura',22,'delete_tbunitamisura'),(88,'Can view Unit?? di Misura',22,'view_tbunitamisura'),(89,'Can add Appellativo',23,'add_tbappellativo'),(90,'Can change Appellativo',23,'change_tbappellativo'),(91,'Can delete Appellativo',23,'delete_tbappellativo'),(92,'Can view Appellativo',23,'view_tbappellativo'),(93,'Can add Categoria IVA',24,'add_tbcategoriaiva'),(94,'Can change Categoria IVA',24,'change_tbcategoriaiva'),(95,'Can delete Categoria IVA',24,'delete_tbcategoriaiva'),(96,'Can view Categoria IVA',24,'view_tbcategoriaiva'),(97,'Can add Categoria Tariffa',25,'add_tbcategorietariffe'),(98,'Can change Categoria Tariffa',25,'change_tbcategorietariffe'),(99,'Can delete Categoria Tariffa',25,'delete_tbcategorietariffe'),(100,'Can view Categoria Tariffa',25,'view_tbcategorietariffe'),(101,'Can add Modalit?? Pagamento',26,'add_tbmodalitapagamento'),(102,'Can change Modalit?? Pagamento',26,'change_tbmodalitapagamento'),(103,'Can delete Modalit?? Pagamento',26,'delete_tbmodalitapagamento'),(104,'Can view Modalit?? Pagamento',26,'view_tbmodalitapagamento'),(105,'Can add Tipo Pagamento',27,'add_tbtipopagamento'),(106,'Can change Tipo Pagamento',27,'change_tbtipopagamento'),(107,'Can delete Tipo Pagamento',27,'delete_tbtipopagamento'),(108,'Can view Tipo Pagamento',27,'view_tbtipopagamento');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES (1,'argon2$argon2id$v=19$m=102400,t=2,p=8$WDlBYkNOZkcxbEJpVnZyaXpNT0pCdg$oQGeo6qPOSy1eoTaOtCTbJT8iPxhTS8MXJLpwR0pnT0','2025-12-23 22:05:17.985366',1,'mpoggi','Matteo','Poggi','mpoggi@soluzionicnc.it',1,1,'2025-11-30 19:48:58.267517'),(2,'',NULL,0,'1_gestore','Marco','Ciacci','gestore@test.com',0,1,'2025-11-30 19:51:08.305409'),(3,'',NULL,0,'operatore','Operatore','Magazzino','operatore@test.com',0,1,'2025-11-30 19:51:08.309387'),(4,'',NULL,0,'visualizzatore','Visualizzatore','Sistema','vis@test.com',0,1,'2025-11-30 19:51:08.316151'),(5,'argon2$argon2id$v=19$m=102400,t=2,p=8$Vmh2SllwUkJ2eGZpUVphM1RYQm9YbQ$fdJoT611iawLXISX0y7rDyyKTwwZAabiVNtI+ZtU6Jc','2025-12-23 15:56:49.147801',1,'mdellariva','Maurizio','Della Riva','mdellariva@soluzionicnc.it',0,1,'2025-11-30 21:14:34.053353'),(6,'argon2$argon2id$v=19$m=102400,t=2,p=8$cnk3T0R2OHowZXd2TTVCaGYxVXlUNQ$2grApQ4y3fyOh/H/9DeA/IHhTv9yTXxWGuuKM9no11c',NULL,0,'gspernacchia','Giacomino','Spernacchia','gspernacchia@soluzionicnc.it',0,1,'2025-12-05 21:59:52.529721');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `azioni_utenti`
--

DROP TABLE IF EXISTS `azioni_utenti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `azioni_utenti` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL,
  `tipo_azione` varchar(20) NOT NULL,
  `data_azione` datetime(6) NOT NULL,
  `dettagli` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `azioni_uten_usernam_dcae0a_idx` (`username`,`tipo_azione`),
  KEY `azioni_uten_data_az_bd8fca_idx` (`data_azione`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `azioni_utenti`
--

LOCK TABLES `azioni_utenti` WRITE;
/*!40000 ALTER TABLE `azioni_utenti` DISABLE KEYS */;
INSERT INTO `azioni_utenti` (`id`, `username`, `tipo_azione`, `data_azione`, `dettagli`) VALUES (1,'mdellariva','ARTICOLO','2025-12-06 21:19:20.773656','Creato articolo: int8904'),(2,'mdellariva','FORNITORE','2025-12-06 21:24:11.800375','Creato fornitore: PneumaticCenter'),(3,'mpoggi','ARTICOLO','2025-12-06 22:58:22.719298','Creato articolo: Ric679011'),(4,'mpoggi','ARTICOLO','2025-12-06 23:24:55.040274','Creato articolo con SCM: Ric77635577'),(5,'mpoggi','MODELLO_SCM','2025-12-07 01:19:18.442030','Creato modello SCM: Accord500'),(6,'mpoggi','MODELLO_SCM','2025-12-07 01:20:23.100804','Creato modello SCM: A600'),(7,'mpoggi','ARTICOLO','2025-12-08 11:23:49.099881','Creato articolo con SCM: Ric-00018272'),(8,'mpoggi','ARTICOLO','2025-12-08 16:19:40.212737','Creato articolo: Ric-6654783'),(9,'mpoggi','ARTICOLO','2025-12-08 17:23:40.827469','Creato articolo: Ric-667382'),(10,'mpoggi','IMMAGINE','2025-12-08 23:21:35.794298','Aggiunta immagine ad articolo esistente: Ric77635577'),(11,'mpoggi','IMMAGINE','2025-12-08 23:30:34.930038','Aggiunta immagine a nuovo articolo: RiC-888999'),(12,'mpoggi','ARTICOLO','2025-12-08 23:30:34.931673','Creato articolo: RiC-888999'),(13,'mpoggi','IMMAGINE','2025-12-09 00:14:06.030413','Aggiunta immagine a nuovo articolo: Ric-8885553'),(14,'mpoggi','ARTICOLO','2025-12-09 00:14:06.032623','Creato articolo: Ric-8885553'),(15,'mdellariva','ARTICOLO','2025-12-20 14:15:02.101239','Creato articolo: Ric-1234569'),(16,'mdellariva','IMMAGINE','2025-12-20 14:16:07.575691','Aggiunta immagine ad articolo esistente: Ric-1234569'),(17,'mdellariva','IMMAGINE','2025-12-20 15:04:13.322693','Aggiunta immagine a nuovo articolo: Ric-987345'),(18,'mdellariva','ARTICOLO','2025-12-20 15:04:13.324548','Creato articolo: Ric-987345'),(19,'mpoggi','CARICO','2025-12-20 18:02:24.624729','Carico articolo: Ric-987345'),(20,'mpoggi','FORNITORE','2025-12-22 23:20:45.664577','Creato fornitore: SCM Group.SPA');
/*!40000 ALTER TABLE `azioni_utenti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorie` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `nome_categoria` varchar(50) NOT NULL,
  `descrizione` varchar(200) DEFAULT NULL,
  `stato_attivo` tinyint(4) DEFAULT 1,
  `creato_il` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificato_il` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `id_categoria_padre` int(11) DEFAULT NULL,
  `livello` int(11) NOT NULL,
  `ordine` int(11) NOT NULL,
  PRIMARY KEY (`id_categoria`),
  KEY `idx_stato` (`stato_attivo`),
  KEY `idx_nome` (`nome_categoria`),
  KEY `categorie_id_cate_a1dbda_idx` (`id_categoria_padre`),
  KEY `categorie_livello_9702e2_idx` (`livello`),
  CONSTRAINT `categorie_id_categoria_padre_5703c6b4_fk_categorie_id_categoria` FOREIGN KEY (`id_categoria_padre`) REFERENCES `categorie` (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorie`
--

LOCK TABLES `categorie` WRITE;
/*!40000 ALTER TABLE `categorie` DISABLE KEYS */;
INSERT INTO `categorie` (`id_categoria`, `nome_categoria`, `descrizione`, `stato_attivo`, `creato_il`, `modificato_il`, `id_categoria_padre`, `livello`, `ordine`) VALUES (1,'Motore','Parti motore e componenti',1,'2025-11-30 18:49:37','2025-12-07 22:43:48',15,1,0),(2,'Trasmissione','Sistemi di trasmissione',1,'2025-11-30 18:49:37','2025-11-30 18:49:37',NULL,0,0),(4,'Freni','Sistemi frenanti',1,'2025-11-30 18:49:37','2025-12-07 22:43:48',15,1,0),(5,'Elettrica','Componenti elettrici',1,'2025-11-30 18:49:37','2025-11-30 18:49:37',NULL,0,0),(6,'Climatizzazione','Sistema di raffreddamento',1,'2025-11-30 18:49:37','2025-12-07 22:43:48',15,1,0),(7,'Filtri','Filtri e manutenzione',1,'2025-11-30 18:49:37','2025-12-08 16:37:49',15,1,0),(8,'Lubrificanti','Oli e lubrificanti',1,'2025-11-30 18:49:37','2025-12-07 22:43:48',15,1,0),(9,'Nessuna','Categoria di fallback per articoli orfani - da caratterizzare manualmente',1,'2025-11-30 21:08:26','2025-12-14 20:27:34',NULL,0,0),(10,'Ventose piano TVN','Ventose per piano TVN dalle ultime record 130 in su',1,'2025-12-06 20:08:12','2025-12-06 20:08:12',NULL,0,0),(11,'Pattini - Viti - Cremagliere - Guide','Parti meccaniche',1,'2025-12-06 23:03:57','2025-12-07 21:42:39',12,1,0),(12,'RICAMBI MECCANICI','Componenti meccanici, cinghie, ingranaggi, cuscinetti, guarnizioni',1,'2025-12-07 21:04:54','2025-12-07 21:04:54',NULL,0,0),(13,'RICAMBI ELETTRICI','Componenti elettrici, schede, motori, sensori, cavi',1,'2025-12-07 21:04:54','2025-12-07 21:04:54',NULL,0,1),(14,'RICAMBI PNEUMATICI','Componenti Pneumatici, tubi, valvole, pompe, cilindri, raccordi',1,'2025-12-07 21:04:54','2025-12-07 21:51:07',NULL,0,2),(15,'AUTO','TUTTO SULLE AUTOMOBILI',1,'2025-12-07 21:37:37','2025-12-07 22:43:48',NULL,0,0),(16,'ACCESSORI PIANI MACCHINE','Ventose, Morsetti, Battute, Innalzatori',1,'2025-12-07 21:53:14','2025-12-07 21:53:14',NULL,0,0),(17,'Pompe Del Vuoto','Tutto Sulle pompe del vuoto',1,'2025-12-07 21:54:02','2025-12-08 16:16:29',NULL,0,0),(18,'Backer','Tutto sulle pompe della Backer',1,'2025-12-07 21:54:46','2025-12-07 22:43:48',17,1,0),(19,'Busch','Tutto sulle pompe della Busch',1,'2025-12-07 21:56:27','2025-12-07 22:43:48',17,1,0),(20,'ritchle','Tutto sulle pompe che esplodono',1,'2025-12-07 21:59:52','2025-12-07 22:43:48',17,1,0),(25,'ciao','',1,'2025-12-07 23:20:14','2025-12-08 16:46:59',30,2,0),(29,'Macchine al Capanno','Macchine da vendere al capanno',1,'2025-12-08 08:35:16','2025-12-08 08:35:16',NULL,0,0),(30,'Pressa Usata','',1,'2025-12-08 08:36:20','2025-12-08 08:36:20',29,1,0),(31,'Guide','Guide prismatiche di varie marche',1,'2025-12-08 08:37:30','2025-12-08 08:43:25',11,2,0),(32,'Pattini','Pattini di tutte le marche',1,'2025-12-08 08:43:59','2025-12-08 08:43:59',11,2,0),(35,'Cremagliere','tutti i tipi',1,'2025-12-08 08:45:51','2025-12-08 08:45:51',11,2,0),(37,'Viti a ricircoloooo','Viti a ricircolo di sfere (viti, chiocciole, viti + chiocciole)',1,'2025-12-08 10:17:13','2025-12-08 17:15:00',11,2,0),(38,'Cuffie','Soffietti, Anelli, Spazzole, Corpo attuativo,',1,'2025-12-08 10:19:32','2025-12-08 10:19:32',12,1,0),(39,'Cuffie Motorizzate','tutto su cuffie motorizzate',1,'2025-12-08 15:32:28','2025-12-08 15:32:28',38,2,0),(40,'Cufffie motorizzate Vecchie','vecchie cuffie  con il trilobato',1,'2025-12-08 15:34:16','2025-12-08 16:27:31',38,2,0),(41,'Cuffia pneumatica 4 posizioni','',1,'2025-12-08 15:35:18','2025-12-08 15:35:18',38,2,0),(42,'Aspirazione','tubi aspirazione, Bocchette in plastica, farfalle, ecc.',1,'2025-12-08 15:36:48','2025-12-08 15:36:48',12,1,0),(43,'mandrini','rshtjrtsrthrts',1,'2025-12-23 14:59:31','2025-12-23 14:59:31',NULL,0,0);
/*!40000 ALTER TABLE `categorie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configurazioni`
--

DROP TABLE IF EXISTS `configurazioni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configurazioni` (
  `chiave` varchar(100) NOT NULL,
  `valore` longtext NOT NULL,
  `tipo_dato` varchar(20) NOT NULL,
  `descrizione` varchar(200) DEFAULT NULL,
  `modificato_il` datetime(6) NOT NULL,
  `modificato_da` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`chiave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configurazioni`
--

LOCK TABLES `configurazioni` WRITE;
/*!40000 ALTER TABLE `configurazioni` DISABLE KEYS */;
INSERT INTO `configurazioni` (`chiave`, `valore`, `tipo_dato`, `descrizione`, `modificato_il`, `modificato_da`) VALUES ('backup_dir','D:\\SVILUPPO MATTEO\\Progetti\\GestioneMagazzinoRicambi Goose\\backups','string','Cartella di destinazione per i backup del database','2025-12-05 23:49:42.635592',NULL),('backup_retention_days','30','integer','Giorni di conservazione dei backup prima della pulizia automatica','2025-12-05 23:49:42.642130',NULL),('mysql_bin_path','C:\\xampp\\mysql\\bin','string','Percorso della cartella bin di MySQL/MariaDB','2025-12-05 23:49:42.646209',NULL);
/*!40000 ALTER TABLE `configurazioni` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dettaglio_inventario`
--

DROP TABLE IF EXISTS `dettaglio_inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dettaglio_inventario` (
  `id_dettaglio` int(11) NOT NULL AUTO_INCREMENT,
  `id_inventario` int(11) NOT NULL,
  `id_articolo` int(11) NOT NULL,
  `quantita_rilevata` int(11) NOT NULL,
  `quantita_sistema` int(11) NOT NULL,
  `differenza` int(11) GENERATED ALWAYS AS (`quantita_rilevata` - `quantita_sistema`) STORED,
  `note` varchar(200) DEFAULT NULL,
  `creato_il` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_dettaglio`),
  KEY `idx_inventario` (`id_inventario`),
  KEY `idx_articolo` (`id_articolo`),
  KEY `idx_differenza` (`differenza`),
  CONSTRAINT `dettaglio_inventario_ibfk_1` FOREIGN KEY (`id_inventario`) REFERENCES `inventari` (`id_inventario`) ON DELETE CASCADE,
  CONSTRAINT `dettaglio_inventario_ibfk_2` FOREIGN KEY (`id_articolo`) REFERENCES `pezzi_ricambio` (`id_articolo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dettaglio_inventario`
--

LOCK TABLES `dettaglio_inventario` WRITE;
/*!40000 ALTER TABLE `dettaglio_inventario` DISABLE KEYS */;
/*!40000 ALTER TABLE `dettaglio_inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES (1,'2025-11-30 21:14:34.190409','5','mdellariva',1,'[{\"added\": {}}]',4,1),(2,'2025-11-30 21:16:44.597551','5','mdellariva',2,'[{\"changed\": {\"fields\": [\"First name\", \"Last name\", \"Email address\", \"Superuser status\"]}}, {\"changed\": {\"name\": \"Profilo Utente\", \"object\": \"Maurizio Della Riva - Amministratore\", \"fields\": [\"Ruolo\"]}}]',4,1),(3,'2025-11-30 21:19:31.772399','1','Matteo P - Amministratore',2,'[{\"changed\": {\"fields\": [\"Ruolo\", \"Numero Dipendente\"]}}]',7,1),(4,'2025-11-30 21:20:40.626951','1','admin',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',4,1),(5,'2025-11-30 21:21:19.083646','1','admin',2,'[{\"changed\": {\"fields\": [\"Last name\", \"Email address\"]}}]',4,1),(6,'2025-12-08 18:15:00.246160','37','RICAMBI MECCANICI > Pattini - Viti - Cremagliere - Guide > Viti a ricircoloooo',2,'[{\"changed\": {\"fields\": [\"Nome Categoria\"]}}]',9,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (8,'accounts','logaccesso'),(7,'accounts','profiloutente'),(1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(19,'magazzino','azioneutente'),(9,'magazzino','categoria'),(18,'magazzino','configurazione'),(16,'magazzino','dettaglioinventario'),(17,'magazzino','documentoallegato'),(11,'magazzino','fornitore'),(13,'magazzino','giacenza'),(15,'magazzino','inventario'),(20,'magazzino','matricolamacchinascm'),(21,'magazzino','modellomacchinascm'),(14,'magazzino','movimentomagazzino'),(12,'magazzino','pezzoricambio'),(23,'magazzino','tbappellativo'),(24,'magazzino','tbcategoriaiva'),(25,'magazzino','tbcategorietariffe'),(26,'magazzino','tbmodalitapagamento'),(27,'magazzino','tbtipopagamento'),(22,'magazzino','tbunitamisura'),(10,'magazzino','unitamisura'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (1,'contenttypes','0001_initial','2025-11-30 01:09:03.406278'),(2,'auth','0001_initial','2025-11-30 01:09:03.880280'),(3,'admin','0001_initial','2025-11-30 01:09:04.001030'),(4,'admin','0002_logentry_remove_auto_add','2025-11-30 01:09:04.008259'),(5,'admin','0003_logentry_add_action_flag_choices','2025-11-30 01:09:04.016452'),(6,'contenttypes','0002_remove_content_type_name','2025-11-30 01:09:04.071401'),(7,'auth','0002_alter_permission_name_max_length','2025-11-30 01:09:04.120963'),(8,'auth','0003_alter_user_email_max_length','2025-11-30 01:09:04.135748'),(9,'auth','0004_alter_user_username_opts','2025-11-30 01:09:04.145105'),(10,'auth','0005_alter_user_last_login_null','2025-11-30 01:09:04.182949'),(11,'auth','0006_require_contenttypes_0002','2025-11-30 01:09:04.184639'),(12,'auth','0007_alter_validators_add_error_messages','2025-11-30 01:09:04.193354'),(13,'auth','0008_alter_user_username_max_length','2025-11-30 01:09:04.206854'),(14,'auth','0009_alter_user_last_name_max_length','2025-11-30 01:09:04.219331'),(15,'auth','0010_alter_group_name_max_length','2025-11-30 01:09:04.234179'),(16,'auth','0011_update_proxy_permissions','2025-11-30 01:09:04.241411'),(17,'auth','0012_alter_user_first_name_max_length','2025-11-30 01:09:04.253525'),(18,'sessions','0001_initial','2025-11-30 01:09:04.288506'),(19,'accounts','0001_initial','2025-11-30 01:10:16.432081'),(20,'magazzino','0001_initial','2025-11-30 01:10:25.966211'),(21,'magazzino','0002_configurazione','2025-12-05 23:44:25.560547'),(22,'magazzino','0003_azioneutente','2025-12-06 20:52:41.010353'),(23,'magazzino','0004_pezzoricambio_stato_disponibilita','2025-12-06 22:29:14.195196'),(24,'magazzino','0005_remove_pezzoricambio_codice_alternativo','2025-12-06 22:52:16.559933'),(25,'magazzino','0006_pezzoricambio_descrizione_scm_and_more','2025-12-06 23:11:16.554675'),(26,'magazzino','0007_matricolamacchinascm_pezzoricambio_matricola_scm_old_and_more','2025-12-06 23:42:30.194831'),(27,'magazzino','0008_alter_categoria_options_categoria_categoria_padre_and_more','2025-12-07 21:50:19.602480'),(28,'magazzino','0009_pezzoricambio_immagine_and_more','2025-12-08 22:28:45.938570'),(29,'magazzino','0010_alter_azioneutente_tipo_azione_and_more','2025-12-10 20:12:52.315820'),(30,'magazzino','0011_alter_unitamisura_options_tbunitamisura','2025-12-20 13:51:19.178630'),(31,'magazzino','0012_pezzoricambio_tb_unita_misura_and_more','2025-12-20 14:00:52.950145'),(32,'magazzino','0013_mappa_unita_misura_vecchie_a_nuove','2025-12-20 14:52:07.817719'),(33,'magazzino','0014_usa_solo_tbunitamisura','2025-12-20 14:54:27.213749'),(34,'magazzino','0015_tbappellativo_tbcategoriaiva_tbcategorietariffe_and_more','2025-12-20 17:48:32.775281'),(35,'magazzino','0016_auto_20251223_2254','2025-12-23 21:57:21.590355'),(36,'magazzino','0017_add_tbcontatti','2025-12-23 22:03:38.676295');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES ('29zxoz7qknnd8ocarsgop5s7ojk83cp2','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vS352:r8eP-4QoZG1ZSz3JaxLfibWOCJ-73rXGisFHDiVc08k','2025-12-07 01:56:52.085288'),('3f32vim2l7dzm78vflmymvlcbobv8fcq','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vSLRH:l6NK5bSk9PDTRQciQScJUMV3T_zzCpJqvXkdtIXY2FQ','2025-12-07 21:33:03.247353'),('3qcx9c7qq0ess1tsha65exi3h61n932a','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vS4HX:wK12Eo49nH-N-D3whrEvO-RQXeMcD7cpFK9iFS_X90I','2025-12-07 03:13:51.168003'),('42j3oko7wpxfki64gumoibym753imkrh','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vQZ2G:_d-0YpBBaoztxZhE6hdRiM9BcfEw-_N_H9Ibq3PKFTs','2025-12-02 23:39:52.209917'),('5f6q48nw17esmz0h6fh3uferarylb1b6','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vSyXi:Hvj6PApI7BVEktAgFSMn2Bemoe2o97safoUSPWiTGJ8','2025-12-09 15:18:18.971156'),('658nl3xqqls6dedwhgclv6wwjlrit09e','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vTQdW:IgXu3qgvZVT94gN_HkJBJcC6ung6h0L2fLP3tuZ8NUs','2025-12-10 21:18:10.180792'),('b3qcce642slmf0f9zoz6yy3igaaolufr','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vSK4t:xXodPfjE0Bliaj5JdcmCX1tRflXu7isnMndqXKv83VE','2025-12-07 20:05:51.823572'),('bvogzznsthn3wngjyq2693rm9k9rqmxk','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vS0Ts:AvDnZ2V7P6HcfMQI-ZlBXXtfvl12uR-EFzAAOajvyc0','2025-12-06 23:10:20.957776'),('c94xeff3pcll2m4y9tnfoc45vcq8sp2q','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vWybR:47z6kHVJBaBgmn0hqX9r48B_VLG7vLYsxaj1M_yhtiY','2025-12-20 16:10:41.276901'),('cteewexjb6qzizynaxiwcux7tegr1y8c','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vRdST:Cl2e2wa7mRLdg3Z1UUURH5DssNXAc2yKHp0zVc16Afk','2025-12-05 22:35:21.794109'),('dzop8cs9ve7p2jxi4kn84l5h00i7ql1a','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vX1CV:AV4YSeEFGW8akFKsU8Chc4n12EvmmnPsMj1mGoL60uc','2025-12-20 18:57:07.201795'),('g0nabqek5goewy3fe1cwy190iytjloc2','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vSjwX:Sqn4zCDLE2vl2JjNV53SoQx4aLPZV0IDRtsWCY5FG6I','2025-12-08 23:42:57.593124'),('g3vn20my50v7zuwjnhcwlljl671fm5yj','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vWxZw:4_PioWyYHHBAHH-hM_yrwkZ2LtFx7wAeVzzMG28z7tU','2025-12-20 15:05:04.136730'),('gm2e4ive0utzydb8flhjjd85woz57tr6','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vReTJ:2Ovm_YnsitG1yewMNI9_PXX8SDWo6YLXeTVWMxZzj2Q','2025-12-05 23:40:17.882751'),('h6h15icix8qtcrz09v6n6b5qx7ck8zm9','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vSZ9c:SJkV-d5vUS5lNiOgbBhixV4BK4d6TqmeT43YPQNG5yI','2025-12-08 12:11:44.051520'),('hwvsi1j3z8ttknjoguyf9ukzxaaty7zy','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vRymw:LYyOC1gh5Sl0HLeoMerlkZjrJvKwHNDbjnXG2D3xfz0','2025-12-06 21:21:54.809764'),('jem2txxl7p0nd99r3bajstr75jmit6y3','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vUtF0:WIQJJbSu_bmLcKGZvxMu3pNsLuctBxuXtmAGI3WyZyM','2025-12-14 22:02:54.373133'),('jthlq3vdol7ofqxtqbph1yrv9peefz90','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vSOWf:eHpNZGboa-xaTPE2dTv0WxPSKyiYtgIXhzQGw-xRPJU','2025-12-08 00:50:49.941843'),('kso7cf8ppqxaexsc87qhxlshtsoms0ym','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vSNYw:bqR9kciTRVgwfPXnQbwfcA3hmDMl8K2Wb8ffoHoczzI','2025-12-07 23:49:06.236542'),('l9d7ljgp84z28x8sp7y8djv6yk938bii','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vSXbY:RQq-TOoHz_B3RA7rkHYozmaTBywLhLg9mUtmufK0S-c','2025-12-08 10:32:28.913561'),('m2rgk0jv6xtq8ljb7x4c2y1ijy057zsa','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vY9Sn:xEZdaAjgNZ8uhvG_OAMczz8YmR5SJrc8UflKPhfQXpE','2025-12-23 21:58:37.810610'),('mz1or3an79ooxt5kf97pgywjm404776y','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vSfor:VXsJvs_m8f06tQQxGqAXec6zLvKwH1jtt5nphN_6EPc','2025-12-08 19:18:45.605879'),('n0qc0i6d202l7uy4jxswc3ykzunaub2v','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vWco6:mmkc9p-dC7Hj6Gg-JeDwUJjvvwuE4zFLdXxnCNAP7UA','2025-12-19 16:54:18.245308'),('n8sqmianlpq5hxpktqmjz3b86wgxxdlo','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vXpPZ:XignH8bHCW7dfU2FE5IRcMCU4Ul7O6xoOP4lVO4cBc8','2025-12-23 00:33:57.813442'),('qlsszzpvmxm74w05odb3wwl1dtoa4jkz','e30:1vY4kj:vsujmRuzD2F2FpKgPduA7nWhXqvAaTHKuTzKXRHKJqY','2025-12-23 16:56:49.143377'),('r9v06vt9ajfftruhc6udyvloa5niogrk','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vSdw8:CI0CNU7RXtQgwY9xs7zCBp66p24fn-nEQoyn2xqKTT8','2025-12-08 17:18:08.038204'),('rnjpxoyasxju8m0ye3pnc590v6me95li','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vS1SF:1DyDcHEs95MkN6_J2oIa7s0onMBn0jj5m77q6Kuyx04','2025-12-07 00:12:43.050937'),('rxfvdaiperb84tul4tt65f9osmehzt8s','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vScyn:UptCUUaLbtD9th0HJJf12DS7DL_jaQeFGDTweFfQeQs','2025-12-08 16:16:49.096233'),('s1rvnxyflfco6i77pw6fjv32a13lqrt7','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vYAVJ:WWcOjuGX6jQw9FqPUiGn5y9rBVYrK4JyGldXNxXmPhg','2025-12-23 23:05:17.993262'),('sxow3xu5csbl4k2rcs50auw45c227he1','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vSMaw:1-my7fc2qJsetPr-RTx7ClWKXGOdZJ_bNq6DiV1_MKo','2025-12-07 22:47:06.494558'),('ttjf27gh3gs5c2xanwrzooxdoua5ijcr','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vUvSN:PMCDWgD9_rht9bkZDcVOYB3B6K6qjAJx3upfRhRWsnk','2025-12-15 00:24:51.964700'),('ut26hi9bfnie2qy95ntsk3aoa5p0gxvo','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vSt5y:6tXzYiKeWZ1awhEKaqRy0dxMPcKmSoGujl9h_c4sWy0','2025-12-09 09:29:18.033235'),('v5wyx18a5digee7b7ktrz6ecuddp1lmf','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vRffR:WIJLVFNZk-AC3E4PJc-Sj3gZl_QJMiJ6q85VIwk17sY','2025-12-06 00:56:53.910875'),('verfjb0yt09rhcq3l25zlyo1yz8fcr0v','.eJxVjMsOwiAQRf-FtSEMjwou3fsNDTAzUjWQlHZl_HdD0oVu7znnvsUc963Me6d1XlBcBIjT75ZiflIdAB-x3pvMrW7rkuRQ5EG7vDWk1_Vw_w5K7GXUPgSFzoDlxGhSZhs4M0RKBmE6W-09TcqFTETZJe1YKzLAET2A0eLzBQYfOJM:1vPoqW:Y1hrTvkNiiRWULiaQplsDSyKxZuiOj7ZZ0DDlTM5-Z0','2025-11-30 22:20:40.634629'),('vxmd64bot4fv6o7byl19n3dpmu03le2h','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vUvBt:DzGFM0uitqEUZIO-VU6iXJY8KXuZpj7BF3JRg85sgWE','2025-12-15 00:07:49.392846'),('wy9o6zodqncan82req04xbaohm99cx1g','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vSkwA:Kc9nhvEZCvOey-K2j2la2TtomNFP3Zfa_nB5vWToh8k','2025-12-09 00:46:38.143241'),('y5z194gnra0cpmu585ckmi9xa8a7f3wi','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vPppe:ACzvXRZpmB_oLYsaUw1uWAk8FEJz-vLilKNnO6bZ7rc','2025-11-30 23:23:50.348179'),('ynait06c97yhxs5h2ww41w3z60uev9qm','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vY4lT:CupADIyQRHvWhfXqMOyoDuHPUfuBAigUxQxp27i5H2I','2025-12-23 16:57:35.437586'),('yx6512k06k92pm8pm9hgeakis23kajpi','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vSiOi:amx7QSgH0Dr8FakBTbqoZrEceDQCivnotD3AafeiBf4','2025-12-08 22:03:56.083870'),('zkogsxcz1m6zghysidlhnfxrkybeonu2','.eJxVjDEOgzAMAP_iuYpqYxNg7M4bIuOEhrYCicBU9e8VEkO73p3uDUH3LYe9pDVMEToQuPyyQe2Z5kPEh873xdkyb-s0uCNxpy2uX2J63c72b5C1ZOigFfUVWVMpIeFYDzgmNUJqR08pMTORSVTzIshSYS1ivonMLHaNCJ8vzm03BA:1vUuBS:sGWQcOVAiZicR_dFF0Zy17wXgx0-6AXqKcUmNhxrTsk','2025-12-14 23:03:18.700373'),('zvo9zgvpveb30uj1praoce173rmzm7rc','.eJxVjEsKwjAUAO_y1hKSvpiSLt17hvA-qalKAv2sineXQhe6nRlmh0TbWtK25DlNCgM4uPwyJnnlegh9Un00I62u88TmSMxpF3Nvmt-3s_0bFFoKDDCi9pSvyozWd-p4JFH2wjYiC_bobCArPkSO5ChwCCpeGHmMHWKGzxcVfTj8:1vSHXE:FPss4Z_xXK4DWWk84nQLOe_JYTyMOocRq7dGtfE_PCY','2025-12-07 17:22:56.238606');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documenti_allegati`
--

DROP TABLE IF EXISTS `documenti_allegati`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documenti_allegati` (
  `id_documento` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_entita` enum('ARTICOLO','MOVIMENTO','FORNITORE') NOT NULL,
  `id_entita` int(11) NOT NULL,
  `tipo_documento` varchar(50) DEFAULT NULL,
  `nome_file` varchar(150) NOT NULL,
  `percorso_file` varchar(250) NOT NULL,
  `data_caricamento` timestamp NOT NULL DEFAULT current_timestamp(),
  `operatore` varchar(50) DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id_documento`),
  KEY `idx_entita` (`tipo_entita`,`id_entita`),
  KEY `idx_tipo_documento` (`tipo_documento`),
  KEY `idx_data` (`data_caricamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documenti_allegati`
--

LOCK TABLES `documenti_allegati` WRITE;
/*!40000 ALTER TABLE `documenti_allegati` DISABLE KEYS */;
/*!40000 ALTER TABLE `documenti_allegati` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fornitori`
--

DROP TABLE IF EXISTS `fornitori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fornitori` (
  `id_fornitore` int(11) NOT NULL AUTO_INCREMENT,
  `ragione_sociale` varchar(100) NOT NULL,
  `indirizzo` varchar(150) DEFAULT NULL,
  `citta` varchar(50) DEFAULT NULL,
  `cap` varchar(10) DEFAULT NULL,
  `provincia` varchar(2) DEFAULT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `partita_iva` varchar(20) DEFAULT NULL,
  `tempo_medio_consegna_giorni` int(11) DEFAULT 7,
  `note` text DEFAULT NULL,
  `stato_attivo` tinyint(4) DEFAULT 1,
  `creato_il` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificato_il` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_fornitore`),
  KEY `idx_ragione_sociale` (`ragione_sociale`),
  KEY `idx_partita_iva` (`partita_iva`),
  KEY `idx_stato` (`stato_attivo`),
  KEY `idx_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=1002 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fornitori`
--

LOCK TABLES `fornitori` WRITE;
/*!40000 ALTER TABLE `fornitori` DISABLE KEYS */;
INSERT INTO `fornitori` (`id_fornitore`, `ragione_sociale`, `indirizzo`, `citta`, `cap`, `provincia`, `telefono`, `email`, `partita_iva`, `tempo_medio_consegna_giorni`, `note`, `stato_attivo`, `creato_il`, `modificato_il`) VALUES (1,'BOSCH Italia S.p.A.','Via Roma 100, Milano','Milano',NULL,NULL,'+39 02 1234 5678','ordini@bosch.it','00000800123',7,'Bravi ma cari',1,'2025-11-30 18:51:08','2025-12-22 22:19:52'),(2,'MAGNETI MARELLI S.p.A.','Via Verdi 50, Torino',NULL,NULL,NULL,'+39 011 234 5678','info@magnetimarelli.it','00000000200',7,NULL,1,'2025-11-30 18:51:08','2025-11-30 18:51:08'),(4,'BREMBO S.p.A.','Via Brembo 25, Bergamo',NULL,NULL,NULL,'+39 035 215 6111','vendite@brembo.it','00000000400',7,'',0,'2025-11-30 18:51:08','2025-11-30 22:21:18'),(5,'CONTINENTAL AG','Via Europa 1, Bologna',NULL,NULL,NULL,'+39 051 542 5000','info@continental.com','00000000500',7,NULL,1,'2025-11-30 18:51:08','2025-11-30 18:51:08'),(6,'Hiteco','Via Marchiese','Villa Verucchio',NULL,'RN','0541746111','info@hiteco.com','non ricordo',7,'',1,'2025-11-30 20:24:56','2025-11-30 22:20:54'),(999,'Non Specificato','','','','','','','',0,'Fornitore generico usato quando si elimina un fornitore con articoli associati. NON ELIMINARE.',1,'2025-11-30 21:53:05','2025-11-30 21:53:05'),(1000,'Pneumaticenter','Via non mi ricordo','Santarcangelo','47777','RN','+3977888888','info@pneumaticenter.it','1234567890',7,'ciao',1,'2025-12-06 20:24:11','2025-12-08 23:09:42'),(1001,'SCM Group.SPA','Via Emilia, 71','Rimini','47900','RN','0541700100',NULL,NULL,7,'',1,'2025-12-22 22:20:45','2025-12-22 22:20:45');
/*!40000 ALTER TABLE `fornitori` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `giacenze`
--

DROP TABLE IF EXISTS `giacenze`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `giacenze` (
  `id_giacenza` int(11) NOT NULL AUTO_INCREMENT,
  `id_articolo` int(11) NOT NULL,
  `quantita_disponibile` int(11) DEFAULT 0,
  `quantita_impegnata` int(11) DEFAULT 0,
  `quantita_prenotata` int(11) DEFAULT 0,
  `ultimo_aggiornamento` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_giacenza`),
  UNIQUE KEY `id_articolo` (`id_articolo`),
  KEY `idx_articolo` (`id_articolo`),
  CONSTRAINT `giacenze_ibfk_1` FOREIGN KEY (`id_articolo`) REFERENCES `pezzi_ricambio` (`id_articolo`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `giacenze`
--

LOCK TABLES `giacenze` WRITE;
/*!40000 ALTER TABLE `giacenze` DISABLE KEYS */;
INSERT INTO `giacenze` (`id_giacenza`, `id_articolo`, `quantita_disponibile`, `quantita_impegnata`, `quantita_prenotata`, `ultimo_aggiornamento`) VALUES (1,1,15,12,0,'2025-11-30 18:51:08'),(2,2,3,1,0,'2025-11-30 18:51:08'),(4,4,9,3,0,'2025-11-30 18:51:08'),(5,5,8,3,0,'2025-11-30 18:51:08'),(6,6,8,5,0,'2025-11-30 18:51:08'),(8,8,12,2,0,'2025-11-30 18:51:08'),(9,9,4,1,0,'2025-11-30 18:51:08'),(10,10,15,5,0,'2025-11-30 18:51:08'),(11,11,8,5,0,'2025-11-30 18:51:08'),(12,12,0,1,0,'2025-12-14 21:55:18'),(13,13,3,0,0,'2025-11-30 18:51:08'),(14,14,3,1,0,'2025-11-30 18:51:08'),(15,15,13,9,0,'2025-11-30 18:51:08'),(16,16,28,1,0,'2025-11-30 22:04:32'),(17,17,14,11,0,'2025-11-30 18:51:08'),(19,19,28,4,0,'2025-11-30 22:19:19'),(20,20,0,0,0,'2025-12-06 20:19:20'),(21,21,0,0,0,'2025-12-06 21:58:22'),(22,22,0,0,0,'2025-12-06 22:24:55'),(23,23,0,0,0,'2025-12-08 10:23:49'),(24,24,0,0,0,'2025-12-08 15:19:40'),(25,25,0,0,0,'2025-12-08 16:23:40'),(26,26,0,0,0,'2025-12-08 22:30:34'),(27,27,0,0,0,'2025-12-08 23:14:06'),(28,28,0,0,0,'2025-12-20 13:15:02'),(29,29,10,0,0,'2025-12-20 17:02:24');
/*!40000 ALTER TABLE `giacenze` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventari`
--

DROP TABLE IF EXISTS `inventari`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventari` (
  `id_inventario` int(11) NOT NULL AUTO_INCREMENT,
  `data_inventario` date NOT NULL,
  `operatore` varchar(50) NOT NULL,
  `stato` enum('IN_CORSO','CHIUSO','APPROVATO') DEFAULT 'IN_CORSO',
  `note` text DEFAULT NULL,
  `creato_il` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificato_il` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_inventario`),
  KEY `idx_data` (`data_inventario`),
  KEY `idx_stato` (`stato`),
  KEY `idx_operatore` (`operatore`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventari`
--

LOCK TABLES `inventari` WRITE;
/*!40000 ALTER TABLE `inventari` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventari` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_accessi`
--

DROP TABLE IF EXISTS `log_accessi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_accessi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `data_accesso` datetime(6) NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `user_agent` longtext DEFAULT NULL,
  `success` tinyint(1) NOT NULL,
  `motivo_fallimento` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `log_accessi_data_ac_fcc71b_idx` (`data_accesso`),
  KEY `log_accessi_user_id_ba5464_idx` (`user_id`,`data_accesso`),
  CONSTRAINT `log_accessi_user_id_c17ab231_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_accessi`
--

LOCK TABLES `log_accessi` WRITE;
/*!40000 ALTER TABLE `log_accessi` DISABLE KEYS */;
INSERT INTO `log_accessi` (`id`, `data_accesso`, `ip_address`, `user_agent`, `success`, `motivo_fallimento`, `user_id`) VALUES (1,'2025-11-30 20:34:58.654416','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',0,'Password non corretta',1),(2,'2025-11-30 20:35:11.214149','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',1,NULL,1),(3,'2025-11-30 22:22:31.047078','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',0,'Password non corretta',1),(4,'2025-11-30 22:22:39.476148','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',0,'Password non corretta',1),(5,'2025-11-30 22:23:50.343099','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',1,NULL,5),(6,'2025-12-02 22:39:51.710667','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',1,NULL,5),(7,'2025-12-05 21:35:21.474101','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',1,NULL,5),(8,'2025-12-05 22:40:17.826723','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',1,NULL,5),(9,'2025-12-05 23:56:53.900870','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',1,NULL,5),(10,'2025-12-06 20:21:54.532075','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',1,NULL,5),(11,'2025-12-06 21:22:40.994921','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',1,NULL,5),(12,'2025-12-06 22:08:36.452787','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',1,NULL,1),(13,'2025-12-06 23:12:43.036374','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',1,NULL,1),(14,'2025-12-07 00:56:52.069567','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',1,NULL,1),(15,'2025-12-07 02:13:51.150382','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(16,'2025-12-07 16:22:55.835622','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(17,'2025-12-07 19:05:51.816036','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(18,'2025-12-07 20:33:03.227541','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(19,'2025-12-07 21:47:06.482485','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(20,'2025-12-07 22:49:06.166922','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(21,'2025-12-07 23:50:49.914353','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(22,'2025-12-08 09:32:28.893386','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(23,'2025-12-08 11:11:43.629619','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(24,'2025-12-08 15:16:49.087711','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(25,'2025-12-08 16:18:08.012281','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(26,'2025-12-08 17:20:55.148023','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(27,'2025-12-08 18:18:45.599169','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(28,'2025-12-08 21:03:55.596614','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(29,'2025-12-08 22:42:57.584234','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(30,'2025-12-08 23:46:38.133530','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(31,'2025-12-09 08:29:18.013862','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,5),(32,'2025-12-09 14:18:18.937455','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,5),(33,'2025-12-10 20:18:09.730474','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,5),(34,'2025-12-14 21:02:54.193395','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,5),(35,'2025-12-14 22:03:18.568406','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,5),(36,'2025-12-14 23:07:49.272634','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,5),(37,'2025-12-14 23:24:51.928591','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,5),(38,'2025-12-19 15:54:17.763886','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,5),(39,'2025-12-20 14:05:03.718207','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,5),(40,'2025-12-20 15:10:41.263271','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,5),(41,'2025-12-20 17:57:07.183390','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(42,'2025-12-22 23:11:48.370541','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(43,'2025-12-22 23:33:57.808575','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,5),(44,'2025-12-23 15:57:35.431912','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(45,'2025-12-23 20:58:37.806883','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1),(46,'2025-12-23 22:05:17.990645','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',1,NULL,1);
/*!40000 ALTER TABLE `log_accessi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matricole_macchine_scm`
--

DROP TABLE IF EXISTS `matricole_macchine_scm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matricole_macchine_scm` (
  `id_matricola` int(11) NOT NULL AUTO_INCREMENT,
  `id_modello` int(11) NOT NULL,
  `matricola_macchina` varchar(100) NOT NULL,
  `anno` int(11) DEFAULT NULL,
  `stato_attivo` tinyint(1) NOT NULL,
  `creato_il` datetime(6) NOT NULL,
  `modificato_il` datetime(6) NOT NULL,
  PRIMARY KEY (`id_matricola`),
  UNIQUE KEY `matricola_macchina` (`matricola_macchina`),
  KEY `matricole_m_id_mode_f582b2_idx` (`id_modello`),
  CONSTRAINT `fk_matricola_modello` FOREIGN KEY (`id_modello`) REFERENCES `modelli_macchine_scm` (`id_modello`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matricole_macchine_scm`
--

LOCK TABLES `matricole_macchine_scm` WRITE;
/*!40000 ALTER TABLE `matricole_macchine_scm` DISABLE KEYS */;
INSERT INTO `matricole_macchine_scm` (`id_matricola`, `id_modello`, `matricola_macchina`, `anno`, `stato_attivo`, `creato_il`, `modificato_il`) VALUES (26,1,'AA1/000681',2018,1,'2025-12-07 02:30:54.356800','2025-12-07 02:30:54.356800'),(27,1,'AA1/001250',2019,1,'2025-12-07 02:30:54.356800','2025-12-07 02:30:54.356800'),(28,1,'AA1/014696',2020,1,'2025-12-07 02:30:54.356800','2025-12-07 02:30:54.356800'),(29,1,'AA10012345',2021,1,'2025-12-07 02:30:54.356800','2025-12-07 02:30:54.356800'),(30,2,'AA2/000127',2019,1,'2025-12-07 02:30:54.356800','2025-12-07 02:30:54.356800'),(31,2,'AA2/001458',2020,1,'2025-12-07 02:30:54.356800','2025-12-07 02:30:54.356800'),(32,3,'AA1/002150',2017,1,'2025-12-07 02:30:54.356800','2025-12-07 02:30:54.356800'),(33,3,'AA1/003200',2018,1,'2025-12-07 02:30:54.356800','2025-12-07 02:30:54.356800'),(34,4,'ACL/001/21',2021,1,'2025-12-07 02:30:54.356800','2025-12-07 02:30:54.356800'),(35,4,'ACL/002/22',2022,1,'2025-12-07 02:30:54.356800','2025-12-07 02:30:54.356800'),(36,5,'ACL/003/23',2023,1,'2025-12-07 02:30:54.356800','2025-12-07 02:30:54.356800'),(37,5,'ACL/004/24',2024,1,'2025-12-07 02:30:54.356800','2025-12-07 02:30:54.356800');
/*!40000 ALTER TABLE `matricole_macchine_scm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modelli_macchine_scm`
--

DROP TABLE IF EXISTS `modelli_macchine_scm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modelli_macchine_scm` (
  `id_modello` int(11) NOT NULL AUTO_INCREMENT,
  `nome_modello` varchar(100) NOT NULL,
  `gamma` varchar(100) DEFAULT NULL,
  `stato_attivo` tinyint(1) NOT NULL DEFAULT 1,
  `creato_il` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `modificato_il` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id_modello`),
  UNIQUE KEY `nome_modello` (`nome_modello`),
  KEY `modelli_m_nome_mo_8a9e4f_idx` (`nome_modello`),
  KEY `modelli_m_gamma_9c8b5a_idx` (`gamma`),
  KEY `modelli_m_stato_a_2d4e1c_idx` (`stato_attivo`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modelli_macchine_scm`
--

LOCK TABLES `modelli_macchine_scm` WRITE;
/*!40000 ALTER TABLE `modelli_macchine_scm` DISABLE KEYS */;
INSERT INTO `modelli_macchine_scm` (`id_modello`, `nome_modello`, `gamma`, `stato_attivo`, `creato_il`, `modificato_il`) VALUES (1,'RD100NT TVN',NULL,1,'2025-12-07 01:31:13.634361','2025-12-07 01:31:13.634361'),(2,'RD110NT TVN PR',NULL,1,'2025-12-07 01:31:13.634361','2025-12-07 01:31:13.634361'),(3,'RECORD 240',NULL,1,'2025-12-07 01:31:13.634361','2025-12-07 01:31:13.634361'),(4,'ACCORD 40',NULL,1,'2025-12-07 01:31:13.634361','2025-12-07 01:31:13.634361'),(5,'ACCORD 40FX',NULL,1,'2025-12-07 01:31:13.634361','2025-12-07 01:31:13.634361'),(26,'Accord500','Gamma 2025',1,'2025-12-07 01:19:18.437041','2025-12-07 01:20:46.470505'),(27,'A600','Gamma 2025',1,'2025-12-07 01:20:23.096761','2025-12-07 01:20:23.096862');
/*!40000 ALTER TABLE `modelli_macchine_scm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimenti_magazzino`
--

DROP TABLE IF EXISTS `movimenti_magazzino`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movimenti_magazzino` (
  `id_movimento` int(11) NOT NULL AUTO_INCREMENT,
  `id_articolo` int(11) NOT NULL,
  `data_movimento` datetime NOT NULL,
  `tipo_movimento` enum('CARICO','SCARICO','RETTIFICA','RESO_FORNITORE') NOT NULL,
  `quantita` int(11) NOT NULL,
  `id_fornitore` int(11) DEFAULT NULL,
  `causale` varchar(150) DEFAULT NULL,
  `numero_documento` varchar(50) DEFAULT NULL,
  `operatore` varchar(50) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `creato_il` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_movimento`),
  KEY `idx_articolo` (`id_articolo`),
  KEY `idx_data_movimento` (`data_movimento`),
  KEY `idx_tipo_movimento` (`tipo_movimento`),
  KEY `idx_fornitore` (`id_fornitore`),
  KEY `idx_operatore` (`operatore`),
  CONSTRAINT `movimenti_magazzino_ibfk_1` FOREIGN KEY (`id_articolo`) REFERENCES `pezzi_ricambio` (`id_articolo`),
  CONSTRAINT `movimenti_magazzino_ibfk_2` FOREIGN KEY (`id_fornitore`) REFERENCES `fornitori` (`id_fornitore`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimenti_magazzino`
--

LOCK TABLES `movimenti_magazzino` WRITE;
/*!40000 ALTER TABLE `movimenti_magazzino` DISABLE KEYS */;
INSERT INTO `movimenti_magazzino` (`id_movimento`, `id_articolo`, `data_movimento`, `tipo_movimento`, `quantita`, `id_fornitore`, `causale`, `numero_documento`, `operatore`, `note`, `creato_il`) VALUES (1,1,'2025-11-30 19:51:08','CARICO',8,5,NULL,'OA9982','admin','Movimento di test - CARICO','2025-11-30 18:51:08'),(2,1,'2025-11-30 19:51:08','SCARICO',4,NULL,NULL,'VD1118','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(3,1,'2025-11-30 19:51:08','SCARICO',3,NULL,NULL,'VD9000','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(4,1,'2025-11-30 19:51:08','CARICO',22,4,NULL,'OA8156','admin','Movimento di test - CARICO','2025-11-30 18:51:08'),(5,2,'2025-11-30 19:51:08','SCARICO',5,NULL,NULL,'VD8265','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(6,2,'2025-11-30 19:51:08','SCARICO',9,NULL,NULL,'VD7624','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(7,2,'2025-11-30 19:51:08','SCARICO',4,NULL,NULL,'VD7142','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(8,2,'2025-11-30 19:51:08','SCARICO',5,NULL,NULL,'VD3926','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(9,2,'2025-11-30 19:51:08','CARICO',5,1,NULL,'OA5928','admin','Movimento di test - CARICO','2025-11-30 18:51:08'),(15,4,'2025-11-30 19:51:08','SCARICO',3,NULL,NULL,'VD5542','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(16,4,'2025-11-30 19:51:08','RETTIFICA',-3,NULL,NULL,'RET2677','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(17,4,'2025-11-30 19:51:08','SCARICO',3,NULL,NULL,'VD9925','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(18,4,'2025-11-30 19:51:08','RETTIFICA',5,NULL,NULL,'RET3491','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(19,5,'2025-11-30 19:51:08','RETTIFICA',1,NULL,NULL,'RET1192','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(20,5,'2025-11-30 19:51:08','SCARICO',1,NULL,NULL,'VD7118','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(21,5,'2025-11-30 19:51:08','CARICO',17,2,NULL,'OA5669','admin','Movimento di test - CARICO','2025-11-30 18:51:08'),(22,6,'2025-11-30 19:51:08','RETTIFICA',4,NULL,NULL,'RET1739','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(23,6,'2025-11-30 19:51:08','SCARICO',9,NULL,NULL,'VD7953','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(24,6,'2025-11-30 19:51:08','SCARICO',2,NULL,NULL,'VD1928','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(25,6,'2025-11-30 19:51:08','SCARICO',1,NULL,NULL,'VD6043','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(29,8,'2025-11-30 19:51:08','SCARICO',8,NULL,NULL,'VD7729','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(30,8,'2025-11-30 19:51:08','SCARICO',6,NULL,NULL,'VD9491','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(31,8,'2025-11-30 19:51:08','CARICO',24,4,NULL,'OA5457','admin','Movimento di test - CARICO','2025-11-30 18:51:08'),(32,8,'2025-11-30 19:51:08','SCARICO',10,NULL,NULL,'VD2270','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(33,9,'2025-11-30 19:51:08','RETTIFICA',4,NULL,NULL,'RET5652','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(34,9,'2025-11-30 19:51:08','SCARICO',3,NULL,NULL,'VD4460','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(35,9,'2025-11-30 19:51:08','RETTIFICA',-1,NULL,NULL,'RET8937','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(36,9,'2025-11-30 19:51:08','CARICO',9,5,NULL,'OA4855','admin','Movimento di test - CARICO','2025-11-30 18:51:08'),(37,9,'2025-11-30 19:51:08','SCARICO',2,NULL,NULL,'VD6765','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(38,10,'2025-11-30 19:51:08','RETTIFICA',5,NULL,NULL,'RET2947','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(39,10,'2025-11-30 19:51:08','RETTIFICA',3,NULL,NULL,'RET8830','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(40,10,'2025-11-30 19:51:08','SCARICO',4,NULL,NULL,'VD8046','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(41,10,'2025-11-30 19:51:08','SCARICO',4,NULL,NULL,'VD1501','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(42,11,'2025-11-30 19:51:08','SCARICO',1,NULL,NULL,'VD4772','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(43,11,'2025-11-30 19:51:08','CARICO',11,999,NULL,'OA3626','admin','Movimento di test - CARICO','2025-11-30 18:51:08'),(44,11,'2025-11-30 19:51:08','SCARICO',8,NULL,NULL,'VD1777','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(45,11,'2025-11-30 19:51:08','SCARICO',5,NULL,NULL,'VD2769','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(46,11,'2025-11-30 19:51:08','RETTIFICA',0,NULL,NULL,'RET9745','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(47,12,'2025-11-30 19:51:08','SCARICO',3,NULL,NULL,'VD5067','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(48,12,'2025-11-30 19:51:08','SCARICO',2,NULL,NULL,'VD7392','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(49,12,'2025-11-30 19:51:08','RETTIFICA',-5,NULL,NULL,'RET1040','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(50,12,'2025-11-30 19:51:08','CARICO',14,999,NULL,'OA9599','admin','Movimento di test - CARICO','2025-11-30 18:51:08'),(51,13,'2025-11-30 19:51:08','RETTIFICA',-1,NULL,NULL,'RET3653','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(52,13,'2025-11-30 19:51:08','RETTIFICA',1,NULL,NULL,'RET1442','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(53,13,'2025-11-30 19:51:08','CARICO',5,999,NULL,'OA6479','admin','Movimento di test - CARICO','2025-11-30 18:51:08'),(54,13,'2025-11-30 19:51:08','RETTIFICA',1,NULL,NULL,'RET9451','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(55,14,'2025-11-30 19:51:08','CARICO',19,5,NULL,'OA2050','admin','Movimento di test - CARICO','2025-11-30 18:51:08'),(56,14,'2025-11-30 19:51:08','SCARICO',2,NULL,NULL,'VD6992','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(57,14,'2025-11-30 19:51:08','RETTIFICA',5,NULL,NULL,'RET1071','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(58,15,'2025-11-30 19:51:08','RETTIFICA',2,NULL,NULL,'RET8796','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(59,15,'2025-11-30 19:51:08','RETTIFICA',0,NULL,NULL,'RET2088','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(60,15,'2025-11-30 19:51:08','RETTIFICA',3,NULL,NULL,'RET4890','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(61,16,'2025-11-30 19:51:08','SCARICO',7,NULL,NULL,'VD4622','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(62,16,'2025-11-30 19:51:08','SCARICO',2,NULL,NULL,'VD2987','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(63,16,'2025-11-30 19:51:08','CARICO',14,2,NULL,'OA1743','admin','Movimento di test - CARICO','2025-11-30 18:51:08'),(64,16,'2025-11-30 19:51:08','CARICO',25,1,NULL,'OA8998','admin','Movimento di test - CARICO','2025-11-30 18:51:08'),(65,17,'2025-11-30 19:51:08','SCARICO',1,NULL,NULL,'VD4861','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(66,17,'2025-11-30 19:51:08','SCARICO',6,NULL,NULL,'VD9109','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(67,17,'2025-11-30 19:51:08','RETTIFICA',0,NULL,NULL,'RET1515','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(68,17,'2025-11-30 19:51:08','RETTIFICA',-5,NULL,NULL,'RET7754','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(69,17,'2025-11-30 19:51:08','SCARICO',10,NULL,NULL,'VD8207','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(73,19,'2025-11-30 19:51:08','SCARICO',8,NULL,NULL,'VD6577','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(74,19,'2025-11-30 19:51:08','RETTIFICA',-1,NULL,NULL,'RET8055','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(75,19,'2025-11-30 19:51:08','CARICO',23,999,NULL,'OA6200','admin','Movimento di test - CARICO','2025-11-30 18:51:08'),(76,19,'2025-11-30 19:51:08','RETTIFICA',3,NULL,NULL,'RET4179','admin','Movimento di test - RETTIFICA','2025-11-30 18:51:08'),(77,19,'2025-11-30 19:51:08','SCARICO',2,NULL,NULL,'VD9886','admin','Movimento di test - SCARICO','2025-11-30 18:51:08'),(78,16,'2025-11-30 23:04:32','CARICO',10,6,'rimediato',NULL,'mdellariva','da mio cugino','2025-11-30 22:04:32'),(79,19,'2025-11-30 23:19:19','CARICO',10,1,'mi serve',NULL,'mdellariva','tutto cosi','2025-11-30 22:19:19'),(80,12,'2025-12-14 22:20:41','SCARICO',4,1,'me li sono mangiati','non serviva','mdellariva','noto 2 che passano a piedi','2025-12-14 21:20:41'),(81,12,'2025-12-14 22:54:18','SCARICO',1,1,'mi serve',NULL,'mdellariva','ciao mare','2025-12-14 21:54:18'),(82,12,'2025-12-14 22:55:18','SCARICO',1,1,'mio',NULL,'mdellariva','','2025-12-14 21:55:18'),(83,29,'2025-12-20 18:02:24','CARICO',10,NULL,NULL,NULL,'mpoggi','regalate','2025-12-20 17:02:24');
/*!40000 ALTER TABLE `movimenti_magazzino` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pezzi_ricambio`
--

DROP TABLE IF EXISTS `pezzi_ricambio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pezzi_ricambio` (
  `id_articolo` int(11) NOT NULL AUTO_INCREMENT,
  `codice_interno` varchar(50) NOT NULL,
  `codice_scm` varchar(11) DEFAULT NULL,
  `codice_fornitore` varchar(50) DEFAULT NULL,
  `descrizione` varchar(200) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `idUnitaMisura` int(11) DEFAULT NULL,
  `giacenza_minima` int(11) DEFAULT 5,
  `giacenza_massima` int(11) DEFAULT 100,
  `prezzo_acquisto` decimal(10,2) DEFAULT NULL,
  `prezzo_acquisto_scm` decimal(10,2) DEFAULT NULL,
  `stato_attivo` tinyint(4) DEFAULT 1,
  `creato_il` timestamp NOT NULL DEFAULT current_timestamp(),
  `modificato_il` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `stato_disponibilita` varchar(4) NOT NULL,
  `descrizione_scm` varchar(200) DEFAULT NULL,
  `id_modello_scm` int(11) DEFAULT NULL,
  `id_matricola_scm` int(11) DEFAULT NULL,
  `id_fornitore` int(11) DEFAULT NULL,
  `matricola_macchina_scm` varchar(100) DEFAULT NULL,
  `modello_macchina_scm` varchar(100) DEFAULT NULL,
  `immagine` varchar(100) DEFAULT NULL,
  `immagine_thumbnail` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_articolo`),
  UNIQUE KEY `codice_interno` (`codice_interno`),
  UNIQUE KEY `pezzi_ricambio_codice_scm_70546a41_uniq` (`codice_scm`),
  KEY `idx_codice_interno` (`codice_interno`),
  KEY `idx_codice_fornitore` (`codice_fornitore`),
  KEY `idx_categoria` (`id_categoria`),
  KEY `idx_stato` (`stato_attivo`),
  KEY `idx_descrizione` (`descrizione`),
  KEY `pezzi_ricambio_id_fornitore_38fbd8b3_fk_fornitori_id_fornitore` (`id_fornitore`),
  KEY `pezzi_ricambio_id_unita_misura_0e79e849_fk_unita_misura_id_unita` (`idUnitaMisura`),
  CONSTRAINT `pezzi_ricambio_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categorie` (`id_categoria`),
  CONSTRAINT `pezzi_ricambio_id_fornitore_38fbd8b3_fk_fornitori_id_fornitore` FOREIGN KEY (`id_fornitore`) REFERENCES `fornitori` (`id_fornitore`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pezzi_ricambio`
--

LOCK TABLES `pezzi_ricambio` WRITE;
/*!40000 ALTER TABLE `pezzi_ricambio` DISABLE KEYS */;
INSERT INTO `pezzi_ricambio` (`id_articolo`, `codice_interno`, `codice_scm`, `codice_fornitore`, `descrizione`, `id_categoria`, `idUnitaMisura`, `giacenza_minima`, `giacenza_massima`, `prezzo_acquisto`, `prezzo_acquisto_scm`, `stato_attivo`, `creato_il`, `modificato_il`, `stato_disponibilita`, `descrizione_scm`, `id_modello_scm`, `id_matricola_scm`, `id_fornitore`, `matricola_macchina_scm`, `modello_macchina_scm`, `immagine`, `immagine_thumbnail`) VALUES (1,'RIC-0001',NULL,NULL,'Filtro olio motore',1,9,5,15,25.50,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'RIC-0002',NULL,NULL,'Set 4 candele NGK',1,12,3,10,45.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,'RIC-0004',NULL,NULL,'Olio cambio automatico',2,10,5,20,22.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,'RIC-0005',NULL,NULL,'Cuscinetto ruota anteriore',2,9,4,12,65.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,'RIC-0006',NULL,NULL,'Ammortizzatore anteriore sx/dx',9,9,3,8,120.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 13:58:18','DISP',NULL,NULL,NULL,NULL,NULL,NULL,'',''),(8,'RIC-0008',NULL,NULL,'Pastiglie freno anteriori',4,13,4,12,55.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,'RIC-0009',NULL,NULL,'Disco freno ventilato',4,9,2,6,95.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,'RIC-0010',NULL,NULL,'Liquido freni DOT 4',4,10,5,15,18.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,'RIC-0011',NULL,NULL,'Batteria 12V 70Ah',5,9,3,8,150.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,'RIC-0012',NULL,NULL,'Alternatore 120A',5,9,2,5,500.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','ESAU',NULL,1,NULL,1,NULL,NULL,'',''),(13,'RIC-0013',NULL,NULL,'Motorino avviamento',5,9,2,6,180.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,'RIC-0014',NULL,NULL,'Compressore aria condizionata',6,9,1,3,380.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,'RIC-0015',NULL,NULL,'Filtro abitacolo auto',6,9,5,15,28.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,'RIC-0016',NULL,NULL,'Filtro aria motore',7,9,8,20,20.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,'RIC-0017',NULL,NULL,'Filtro gasolio motore',7,9,6,15,32.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,'RIC-0019',NULL,NULL,'Grasso lubrificante universale',8,12,8,25,12.00,NULL,1,'2025-11-30 18:51:08','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,'int8904',NULL,'racc1456','Raccordo dritto da 8mm',9,9,5,100,1.00,NULL,1,'2025-12-06 20:19:20','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,'Ric679011',NULL,NULL,'Tubo rilsan da 4mm',9,11,50,100,5.00,10.00,1,'2025-12-06 21:58:22','2025-12-20 14:52:07','ESAU',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,'Ric-776355','0001310282E',NULL,'Inverter KEB F5',1,9,5,100,1500.00,4000.00,1,'2025-12-06 22:24:55','2025-12-20 14:52:07','ESAU','AZIONAM KEB 5KV GDB1111',1,NULL,6,'AA1/014696','Record 242 TVN','articoli/2025/12/inverter_keb_img_dr-f5-d_1496_1920x1920_large.jpg','articoli/thumbnails/2025/12/inverter_keb_img_dr-f5-d_1496_1920x1920_thumb.jpg'),(23,'Ric-000182','0002756784F',NULL,'Soffietto cuffia 350',38,9,2,100,100.00,150.00,1,'2025-12-08 10:23:49','2025-12-20 14:52:07','ESAU',NULL,27,NULL,999,NULL,NULL,'',''),(24,'Ric-665478',NULL,NULL,'Anello Cuffia da 350',38,9,5,100,NULL,NULL,1,'2025-12-08 15:19:40','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,'',''),(25,'Ric-667382',NULL,NULL,'Art Ciao',25,11,5,100,NULL,NULL,1,'2025-12-08 16:23:40','2025-12-20 14:52:07','DISP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,'RiC-888999','0123123120F',NULL,'Valvola pneumax quella li dai',14,9,0,100,250.00,450.00,1,'2025-12-08 22:30:34','2025-12-20 14:52:07','ESAU','Valvola Pneumax 4l + 5o',NULL,NULL,1000,NULL,NULL,'articoli/2025/12/Valvola_Canbus_Pneumax_large.jpg','articoli/thumbnails/2025/12/Valvola_Canbus_Pneumax_thumb.jpg'),(27,'Ric-888555','0002736370H',NULL,'Valvola pneumax monostabile 24vdc',14,9,0,5,NULL,NULL,1,'2025-12-08 23:14:06','2025-12-20 14:52:07','ESAU','Valvola pneumax monostabile 24vdc',NULL,NULL,1000,NULL,NULL,'articoli/2025/12/Valvola_pneumax_monostabile_24vdc_large.jpg','articoli/thumbnails/2025/12/Valvola_pneumax_monostabile_24vdc_thumb.jpg'),(28,'Ric-1234569','0736238634E',NULL,'Fluido Refrigerante per mandrini',9,NULL,1,2,30.00,45.00,1,'2025-12-20 13:15:02','2025-12-20 13:16:07','ORD','Fluido',NULL,NULL,999,NULL,NULL,'articoli/2025/12/0736238634_fluido_large.jpg','articoli/thumbnails/2025/12/0736238634_fluido_thumb.jpg'),(29,'Ric-987345','0391320413C',NULL,'Guarnizione ventose 145x145',16,9,5,100,NULL,22.51,1,'2025-12-20 14:04:13','2025-12-20 14:04:13','ORD','Guarnizione 145x145',NULL,NULL,NULL,NULL,NULL,'articoli/2025/12/Guarnizione_145x145_0391320413C_large.jpg','articoli/thumbnails/2025/12/Guarnizione_145x145_0391320413C_thumb.jpg');
/*!40000 ALTER TABLE `pezzi_ricambio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbappellativo`
--

DROP TABLE IF EXISTS `tbappellativo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbappellativo` (
  `idAppellativo` int(11) NOT NULL AUTO_INCREMENT,
  `Descrizione` varchar(50) NOT NULL,
  PRIMARY KEY (`idAppellativo`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbappellativo`
--

LOCK TABLES `tbappellativo` WRITE;
/*!40000 ALTER TABLE `tbappellativo` DISABLE KEYS */;
INSERT INTO `tbappellativo` (`idAppellativo`, `Descrizione`) VALUES (1,'Sig.'),(2,'Sig.ra'),(3,'Sig.na'),(4,'Dott.'),(5,'Prof.'),(6,'Ing.'),(7,'Generico');
/*!40000 ALTER TABLE `tbappellativo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbcategoriaiva`
--

DROP TABLE IF EXISTS `tbcategoriaiva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbcategoriaiva` (
  `idCategoriaIVA` int(11) NOT NULL AUTO_INCREMENT,
  `NomeCategoria` varchar(100) NOT NULL,
  `ValoreIVA` decimal(5,3) NOT NULL,
  PRIMARY KEY (`idCategoriaIVA`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbcategoriaiva`
--

LOCK TABLES `tbcategoriaiva` WRITE;
/*!40000 ALTER TABLE `tbcategoriaiva` DISABLE KEYS */;
INSERT INTO `tbcategoriaiva` (`idCategoriaIVA`, `NomeCategoria`, `ValoreIVA`) VALUES (1,'Manodopera',0.220),(3,'Rimborso spese',0.220),(4,'Tempo e materiale per sicurezza',0.000),(6,'Ricambi',0.220),(7,'Imposte',0.000),(8,'Manodopera IVA es.',0.000),(9,'Rimborso spese IVA es.',0.000);
/*!40000 ALTER TABLE `tbcategoriaiva` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbcategorietariffe`
--

DROP TABLE IF EXISTS `tbcategorietariffe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbcategorietariffe` (
  `idCategorieTariffe` int(11) NOT NULL AUTO_INCREMENT,
  `CategoriaTariffe` varchar(200) NOT NULL,
  `IsVisible` tinyint(1) NOT NULL,
  PRIMARY KEY (`idCategorieTariffe`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbcategorietariffe`
--

LOCK TABLES `tbcategorietariffe` WRITE;
/*!40000 ALTER TABLE `tbcategorietariffe` DISABLE KEYS */;
INSERT INTO `tbcategorietariffe` (`idCategorieTariffe`, `CategoriaTariffe`, `IsVisible`) VALUES (1,'Assistenza lunga per cliente generico',1),(2,'SCM Assistenza no IVA',1),(3,'OLD - Tariffe Kosmosoft 2011',0),(4,'SCM Produzione no IVA',1),(6,'Kosmosoft 2012',0),(8,'Tariffa oraria concessionari Italia',1),(9,'Assistenza breve per cliente generico',1),(11,'Tariffe Concessionari Estero',1),(12,'Tariffa TecnoMac',0),(13,'Assistenza tariffa agevolata per cliente locale',0),(14,'Tariffa Flat filiale estera',0),(15,'Gemma Group',0),(16,'Tariffa Emmedue',0),(17,'Tariffe CTC con IVA',0),(18,'Tariffe Poliarredo snc',0),(20,'_Falegnameria',0),(21,'Tariffa giornaliera concessionari Italia',1),(22,'Assistenza per clienti Masterwood',0),(23,'Tariffa Pieri',0),(25,'Tariffa giornaliera s/spese concessionari Italia',0),(26,'Tariffa corsi',0);
/*!40000 ALTER TABLE `tbcategorietariffe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbcontatti`
--

DROP TABLE IF EXISTS `tbcontatti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbcontatti` (
  `idContatto` int(11) NOT NULL AUTO_INCREMENT,
  `idCliente` int(11) DEFAULT NULL,
  `idFornitore` int(11) DEFAULT NULL,
  `idAppellativo` int(11) DEFAULT NULL,
  `nome` varchar(100) NOT NULL,
  `cognome` varchar(100) NOT NULL,
  `ruolo` varchar(100) NOT NULL,
  `TelefonoAzienda` varchar(50) NOT NULL,
  `CellulareAzienda` varchar(50) NOT NULL,
  `emailAzienda` varchar(254) NOT NULL,
  `CellularePersonale` varchar(50) NOT NULL,
  `eMailPersonale` varchar(254) NOT NULL,
  `nota` longtext NOT NULL,
  PRIMARY KEY (`idContatto`)
) ENGINE=InnoDB AUTO_INCREMENT=307 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbcontatti`
--

LOCK TABLES `tbcontatti` WRITE;
/*!40000 ALTER TABLE `tbcontatti` DISABLE KEYS */;
INSERT INTO `tbcontatti` (`idContatto`, `idCliente`, `idFornitore`, `idAppellativo`, `nome`, `cognome`, `ruolo`, `TelefonoAzienda`, `CellulareAzienda`, `emailAzienda`, `CellularePersonale`, `eMailPersonale`, `nota`) VALUES (2,4,NULL,1,'Alberto','Fratti','','391000000000','334000000000','afratti@scmgroup.com','','',''),(4,6,NULL,7,'Stefano','Sganzerla','','','','','','',''),(5,9,NULL,1,'Carlo','Gellosi','','544462485','3290503388','cgelosi@radis.it','','','Titolare'),(6,9,NULL,2,'Licia','','','544462485','','licia@legnamiradis.it','','','Amministrazione'),(7,10,NULL,0,'Mauro','Olla','','','339-6907173','legnoquattro@tiscali.it','','',''),(8,11,NULL,0,'Antioco','Piras','','','328/0510018','vivereillegnosnc@tiscali.it','','',''),(9,12,NULL,0,'Cristian','','','543720142','3393542756','manuccisnc@libero.it','','',''),(10,13,NULL,0,'Jan','Mimra','','','','jmimra@panas.cz','','',''),(11,14,NULL,1,'Orazio','Stanghellini','','335-8192378','','info@stanghellini.com','','',''),(12,15,NULL,1,'Alessandro','Rigon','','0445/621221','3471302389','alessandro@falegnameriarigon.it','','',''),(13,18,NULL,1,'Niccolò','Ferri','','3357103748','3357103748','','','',''),(15,20,NULL,1,'Elio','','','0041 191 945 38 41','','info.cslegnami.elio@gmail.com','','','Ufficio Tecnico e operatore macchina'),(16,23,NULL,0,'Tecnomac','','','0543/783112','','','','',''),(18,25,NULL,1,'Mirco','Masè','','465804467','3294229961','info@falegnameriamase.it','','','www.falegnameriamase.it'),(19,26,NULL,1,'Ivan','Scanavino','','0541 790222 - int 18','393 9439728','risorseumane@fontemaggi.it','','','Responsabile fornitori'),(20,26,NULL,1,'Sauro','Bertuccioli','','','348 2657746','','','','Responsabile di produzione e referente per la macchina'),(21,26,NULL,1,'Renzo','Pari','','','','','335 7692698','','Operatore macchina'),(22,28,NULL,1,'Noel','van Aswegen','','','','Noel Van Aswegen <NoelV@vivaeng.co.za>','','',''),(23,29,NULL,1,'Devis','Bombardini','','0542 672767','','dbombardini@imballaggi-industriali.com','','',''),(24,30,NULL,1,'','Ruzzon','','3299305135','','info@falegnameriaruzzon.eu','','',''),(25,31,NULL,1,'Filippo','','','+39 340 7133413','','2fstampe@gmail.com','','',''),(26,33,NULL,0,'Massimo','Cicuti','','0385/49413','392/8609122','info@falegnameriacicuti.it','','',''),(27,34,NULL,1,'Daniele','Amici','','','','daniele@amiciatos.com','','',''),(28,35,NULL,1,'Staale','Sveen','','+47 56 17 44 40','','staale.sveen@inwido.no','','',''),(29,36,NULL,0,'Danilo','Farneti','','','345 5680670','amministrazione@effedisalotti.it','','',''),(30,31,NULL,1,'Marco','Felicetti - titolare','','+39 348 2408530','','info@fmstrutture.com','','',''),(31,14,NULL,NULL,'Elisabetta','amministrazione invio fatture','','0376/840278','','stanghellini@stanghellini.net','','',''),(32,37,NULL,1,'Stelvio','Chiorlin','','02 99055887','333 5965992','stelvio@chiorlin.it','','',''),(33,38,NULL,1,'Michele','','','','347 8854192','michele@falconcase.com','','','Responsabile'),(34,38,NULL,2,'Sabrina','','','','','sabrina@falconcase.com','','','Indirizzo a cui spedire le fatture'),(36,40,NULL,1,'Giacomo','Scarabelli','','051 6056302','','giacomo.scarabelli@gmail.com','','',''),(38,9,NULL,1,'Gianni','responsabile produzione','','5441674122','','','','',''),(39,41,NULL,7,'Generico','','','+32 56 60 13 45','','info@rogiers.be','','',''),(40,41,NULL,1,'Erik','Decoodt','','','+32 0496 529671','edecoodt@rogiers.be','','',''),(41,42,NULL,1,'Gianluca','Marchi','','0541/629103','','marchigianluca@libero.it','','',''),(42,43,NULL,1,'Stefano','Gusberti','','','348 7112553','s.gusberti@oribonetti.it','','',''),(43,44,NULL,0,'Valentina','Genestreti','','','','','','','Amministrazione Hiteco'),(44,46,NULL,1,'Antonio','Paletti','','0863 941497','3394083274','palettinfissi@virgilio.it','','',''),(45,47,NULL,1,'Matteo','Sdruccioli','','','','info@sdruccioli.it','','',''),(46,48,NULL,1,'Daniele','De Giorgi','','388/8111884','','info@degiorgisrl.com','','',''),(47,49,NULL,1,'Francesco','Ortenzi','','','','info@ortenzifalegnameria.com','','',''),(48,50,NULL,1,'Umberto','Turchetto','','-5802','','umberto.turchetto@scmgroup.com','','',''),(49,51,NULL,2,'Paola','Di ciano','','+39 0871 71106','','http://www.naturalegno.com/','','',''),(50,52,NULL,1,'Medoro','Bicchierini','','+39 337 1006087','','mbicchierini@scmgroup.com','','',''),(51,52,NULL,2,'Ramona','Morri','','+39 0549 910412','','ramona.morri@scmgroup.com','','',''),(52,52,NULL,2,'Elisabetta','Zafferani','','','','ezafferani@scmgroup.com','','',''),(53,53,NULL,1,'Luca Maria','Moroni','','','335/5619213','lucamaria.moroni@mit-srl.com','','',''),(54,22,NULL,1,'Roberto','Baldin','','335 740 0393','','','','',''),(55,22,NULL,1,'Diego','Baldin','','337 469 145','','','','',''),(56,55,NULL,1,'Maurizio','Durazzi','','0721 200165','339 7623336','info@demsrl.it','','','Titolare'),(57,55,NULL,2,'Paola','Durazzi','','0721 200165','','info@demsrl.it','','',''),(58,55,NULL,1,'Gilberto','Gorini','','331 356852','','','','',''),(59,57,NULL,1,'Lucio','Gori','','348 7805733','','gorilucio@attiliogori.it','','',''),(60,57,NULL,0,'Ufficio','','','0575 678266','','info@attiliogori.it','','',''),(61,56,NULL,1,'Franco','Pitinari','','','','f.pitinari@cucinelube.it','','',''),(62,58,NULL,1,'Gabriele','Bartoli','','0541 905818','','gbartoli@gemma-group.com','','','Rsponsabile assistenza e U.T.'),(63,58,NULL,1,'','Rosati','','','','arosati@gemma-group.com','','','Direttore e persona a cui inviare le fatture'),(64,43,NULL,1,'Paolo','Ori','','','348 4971921','','','',''),(65,59,NULL,1,'Massimo','Pavarini','','059 6228270','3357116745','info@pavarinimacchine.it','','',''),(66,59,NULL,1,'Simone','Giovanardi','','059 6228270','3342413097','simone@pavarinimacchine.it','','',''),(67,59,NULL,3,'Annalita','amministrazione','','059 693328','','annalita@pavarinimacchine.it','','',''),(68,60,NULL,1,'Antioco','Piras','','','3280510018','antipiras@libero.it','','',''),(69,61,NULL,1,'Claudio','Conforto','','','3939659468','claudioconfortogalli@gmail.com','','',''),(70,62,NULL,1,'Valerio','Pericolosi','','+39 347 4657530','','Falegnameriadvc@gmail.com','','',''),(71,63,NULL,7,'Uffici','','','0971/945533','','poliarredo@poliarredo.it','','',''),(72,63,NULL,1,'Saverio','Grimaldi','','','339 2210657','','','',''),(73,64,NULL,1,'Christian','Montanari','','','+39 335 381 767','christian.montanari@industriemontanari.s','','',''),(74,64,NULL,2,'Roberta','Verzicco','','0549/908926','','verzicco@industriemontanari.sm','','',''),(75,65,NULL,1,'Matteo','Montali','','','','info@emmellearredamenti.com','','',''),(76,66,NULL,1,'Gianluca (=Fratti)','Cavallini','','0577/632871','335 7096792','gianluca.cavallini@scmgroup.com','','','Reponsabile service'),(77,66,NULL,2,'Roberta (=Elisa)','Mascelloni','','0577/632884','','roberta.mascelloni@scmgroup.com','','','Segretaria del service'),(78,66,NULL,2,'Alice (amministrazione)','Lucaroni','','0577/632895','','alucaroni@scmgroup.com','','','Persona a cui inviare le fatture'),(79,67,NULL,2,'Tania','Laas','','','','ana.alfor@gmail.com','','',''),(80,68,NULL,1,'Enrico','Muffagni','','0522-814133','','zanniserramenti@libero.it','','','Titolare'),(81,68,NULL,1,'Enrico','Miari','','0522-814133','','miari.enrico@zanniserramenti.eu','','','Responsabile centro di lavoro'),(82,69,NULL,1,'Luca','Gasparon','','','347 5945469','ufficio@falegnameria-gasparon.com','','',''),(83,70,NULL,1,'Italo','Zandoli','','0547-59656','338-9919885','i.zandoli@alice.it','','',''),(84,73,NULL,1,'Carlo','Cataldo','','','','carlocataldo.ipm@libero.it','','',''),(85,71,NULL,1,'Matteo','Bottegoni','','392 3981125','','bottegonimatteo@libero.it','','','operatore'),(86,74,NULL,1,'Lando','Santerini','','','348 780 7196','lando.santerini@santerinimacchine.it','','',''),(87,74,NULL,0,'Amministrazione','','','','','amministrazione@santerinimacchine.it','','',''),(88,71,NULL,2,'Chiara','Magagnini','','333 9534628','','','','','Figlia'),(89,75,NULL,0,'Alex','','','','334/2915012','inventa@inventa-italy.com','','',''),(90,75,NULL,0,'','','','0721/499408','','amministrazione@inventa-italy.com','','',''),(91,76,NULL,1,'Mauro','Montagner','','348 7765935','','mauromontagner@maut.it','','',''),(92,77,NULL,0,'','Della Rosa','','','3357413052','srlbimal@libero.it','','',''),(93,78,NULL,0,'Salvo','Bandiera','','0931/464312','333/640 1328','bandieramacchine@yahoo.it','','',''),(94,27,NULL,2,'Giovanna','Puligheddu','','0444/356340','392/9707821','info@profilegno.com','','',''),(95,80,NULL,1,'Albert','Ghigi','','','3885494830','','','',''),(96,80,NULL,0,'','','','0541/657312','','amministrazione@infissimontebelli.it','','',''),(97,80,NULL,0,'','','','','','','','',''),(98,82,NULL,0,'Luana','Grossi','','0541/772847','','biothai@biothai.it','','',''),(99,84,NULL,1,'Paolo','Rossi','','+39 335 1239011','','prossi@acm.sm','','',''),(100,85,NULL,0,'Romana','Štrajhar','','+386 0590 13 352','+386 41 420 579','info@rs-group.si','','',''),(101,85,NULL,0,'Ufficio','','','','+386 70 134 370','pisarna@rs-group.si','','',''),(102,85,NULL,0,'Assistenza tecnica','','','','+ 386 70 918 803','servis@rs-group.si','','',''),(103,39,NULL,1,'Gabriele','De Monte','','','340/5905930','demonte.snc@hotmail.it','','',''),(104,87,NULL,0,'Caterina','Tedaldi','','0543/971099','','caterina@bussifalegnameria.it','','',''),(105,88,NULL,0,'Matteo','Mancini','','0721/482300','','matteo.mancini@valerianirossini.it','','',''),(106,88,NULL,0,'Generico','','','','','info@valerianirossini.it','','',''),(107,89,NULL,NULL,'','','','0541 751080','','info@ghines.com','','',''),(108,21,NULL,6,'Andrea','Spazzoli','','541700170','','aspazoli@scmgroup.com','','',''),(109,89,NULL,1,'Andrea','Gabellini','','0541 751080','','a.gabellini@ghines.com','','','Direttore'),(110,89,NULL,1,'Serafino','Ghinelli','','','','','','','Presidente fondatore e proprietario'),(111,90,NULL,1,'Fabrizio','Romei','','335 736 9605','','fabrizioromei@gmail.com','','',''),(112,91,NULL,1,'Attilio','Tortelli','','0733/884013','348/2618970','attiliotortelli@gmail.com','','',''),(113,83,NULL,0,'Betti','Angelini','','','','angelini.elisabetta@gmail.com','','',''),(114,87,NULL,0,'','Bussi','','','335/6549728','','','',''),(116,93,NULL,0,'Samuele','Di Lorenzi','','0721/498050','','dilorenzisamuele@gmail.com','','',''),(117,91,NULL,0,'','','','0734/759738','','info@falerlegno.it','','',''),(118,92,NULL,0,'Mercato Coperto','','','0541/53460','','mussonimacelleria@gmail.com','','',''),(119,94,NULL,1,'Rodolfo','Quaresima','','0721/400309','329/7353086','rodolfo.quaresima@techwood.it','','',''),(120,94,NULL,2,'Luana','Borchia','','0721/400309','','amministrazione@techwood.it','','',''),(121,94,NULL,7,'','','','','','info@techwood.it','','',''),(122,95,NULL,7,'','','','0575/382156','','info@pierimacchine.it','','',''),(123,95,NULL,1,'Fabio','Sciavartini','','','348/3385339','','','',''),(124,96,NULL,1,'Gabriele','Terrasi','','06/9680943','','ufficiotecnico@legnobagno.it','','',''),(125,79,NULL,0,'Nicola','','','','333/4731649','','','',''),(126,97,NULL,1,'Alberto','Faiella','','','348/3384839','info@faietechsrl.it','','',''),(127,98,NULL,1,'Marco','','','0541/727787','335/8322210','marco.olivieri@olivierimobili.com','','',''),(128,98,NULL,7,'Amministrazione','','','','','ufficio.acquisti@olivierimobili.com','','',''),(129,98,NULL,1,'Fabio','Giuliani','','','','fabio.giuliani@olivierimobili.com','','','Responsabile disegno tecnico'),(130,86,NULL,1,'Giuliano','Lanzetti','','','','giulianolanzetti@me.com','','',''),(131,51,NULL,2,'Simona','Paris','','','','amministrazione@naturalegno.com','','',''),(132,98,NULL,1,'Fabrizio','Galvani','','111','','ufficio.acquisti@olivierimobili.com','','','per ddt c/lavoro'),(133,100,NULL,7,'Ristorante','','','0541/752362','','parcopruccoli@libero.it','','',''),(134,100,NULL,7,'Sede','','','0541/383877','','','','',''),(135,101,NULL,1,'Massimo','Nieri','','3473413253','','massi.nieri@gmail.com','','',''),(136,101,NULL,1,'Lorenzo','Dellalunga','','','','lorenzo.dellalunga@cipriani-serramenti.i','','',''),(137,101,NULL,0,'Ufficio contabilità','','','055/640160','','amministrazione@cipriani-serramenti.it','','',''),(138,103,NULL,1,'Loris','Corrò','','0422/22271','','essenzatv@gmail.com','','',''),(139,104,NULL,1,'Ermes','Tisselli','','0541/623883','335/6754529','applicazioni@gtsrl.com','','',''),(140,105,NULL,0,'Matteo','Rogai','','055 8498403','','morphosfi@gmail.com','','',''),(141,14,NULL,1,'Giovanni','Franzoni - commerciale','','349/1670419','','commerciale@stanghellini.com','','',''),(142,106,NULL,0,'ArchiNow','','','','','','','',''),(143,107,NULL,0,'','','','0442/080750','','info@mantovaniarredamenti.it','','',''),(145,98,NULL,1,'Marco','Monticelli','','115','','marco.monticelli@olivierimobili.com','','',''),(146,108,NULL,1,'','','','0541/950317','348/3335414','info@aessearreda.com','','',''),(147,106,NULL,1,'Luca','Mancini','','','','l.mancini@ricamificioriminese.it','','',''),(148,109,NULL,1,'Domenico','Torre','','','','Mimmo@ediltorre.com','','',''),(149,110,NULL,1,'Alessandro','Falconi','','0541791821 tasto2','','tecnico@gyps.it','','','SEDE OPERATIVA'),(150,4,NULL,2,'Elisa','Davoli','','0541/700424','','','','',''),(151,111,NULL,1,'Valerio (padre)','Mondino','','0175/259231','335/6769780','valerio@utensillegno.cn.it','','',''),(152,71,NULL,2,'Laura','Magagnini','','','','magagninilaura@libero.it','','',''),(153,88,NULL,2,'Federica','Ricci','','amministrazione','','federica.ricci@valerianirossini.it','','',''),(154,23,NULL,1,'Gianluca','Medri','','commerciale','335/8044190','gianlucamedri@gmail.com','','',''),(155,95,NULL,2,'Laura','Pasquinini','','imp.comm.verifica fatt.','','info@pierimacchine.it','','',''),(156,95,NULL,2,'Beatrice','Sarri','','imp.comm.verifica fatt.','','info@pierimacchine.it','','',''),(157,113,NULL,0,'','','','035/520576','','info@acerbismarino.it','','',''),(158,114,NULL,1,'Luca Maria','Mancini','','','','l.mancini@ricamificioriminese.it','','',''),(159,115,NULL,1,'Patrick','Mancini','','349/2301832','','mancinipatrick@hotmail.com','','',''),(160,115,NULL,2,'Daniela','amministrazione','','339/2155304','','amministrazione@embassyrimini.com','','',''),(161,115,NULL,0,'PEC','','','','','embassy1870srl@legalmail.it','','',''),(162,116,NULL,1,'Patrizio','Neri (figlio)','','','320/6419724','info@falegnameriaartigiananeri.com','','',''),(163,116,NULL,1,'Alessandro','Neri (padre)','','0573/84211','','','','',''),(164,117,NULL,0,'Anrea','Succi','','','','andrea.succi@celeranet.it','','',''),(165,118,NULL,0,'Archinow','','','','','','','',''),(166,118,NULL,0,'Lella piada e cassoni','','','','','','','',''),(167,119,NULL,1,'Luigi','Recanatese','','049/5388328','','luigi.recanateseschneider-electric.com','','',''),(168,15,NULL,0,'amministrazione','','','','','info@falegnameriarigon.it','','',''),(169,100,NULL,0,'Federico','','','339/4581624','','','','',''),(170,86,NULL,2,'Emma','','','amministrazione','','segreteria@bountyrimini.it','','',''),(171,120,NULL,0,'','','','','','info@redlegno.it','','',''),(172,120,NULL,2,'Ornella','Negrisolo','','071/9465058','','amministrazione@redlegno.it','','',''),(173,4,NULL,1,'Claudio','Claudio','','0541/674719','','ricambi','','',''),(174,123,NULL,0,'','','','075/888558','','info@ebanisterianulli.com','','',''),(175,115,NULL,1,'Massimiliano','Alvisi','','393/3303748','','massimiliano@sale14.net','','',''),(176,41,NULL,1,'Michiel','Vandaele','','','','mvandaele@rogiers.be','','',''),(177,124,NULL,1,'Lunedei','Marco','','','','avv.marcolunedei@yahoo.it','','',''),(178,125,NULL,1,'Luca','Chiriatti','','0541/736536','334/6672909','info@hotelgabbianorimini.com','','',''),(179,126,NULL,0,'','','','758064660','','f-a-r@libero.it','','',''),(180,127,NULL,1,'Stefano','Pelizzo','','','','348/3571894','','',''),(181,127,NULL,1,'Dario','','','0773/752149','','','','',''),(182,127,NULL,2,'Elisa','','','0773/752149','','','','',''),(183,128,NULL,1,'Davide','Benedetti','','','','','','',''),(184,129,NULL,0,'','','','051/531352','','info@poliarredamenti.it','','',''),(185,130,NULL,1,'Klaidi','Koci','','','392 944 4246','ilgrifondoro@hotmail.it','','',''),(186,131,NULL,0,'Loris','Mazzanti','','071/688637','','info@artigianlegno.info','','',''),(187,132,NULL,0,'','','','','','info@scarpettimobili.it','','',''),(188,133,NULL,1,'Marco','Casali','','0541/326882','335/7856268','info@cpmacchinelegno.com','','',''),(189,134,NULL,0,'','','','073/357384','','info@cgmtavoli.it','','',''),(190,134,NULL,0,'','','','073/3579222','','','','',''),(191,135,NULL,0,'Valter','Sabadotto','','0423/64359','348/6929769','info@falegnameriasabadotto.it','','',''),(192,136,NULL,0,'','','','','','reddivanisrl@gmail.com','','',''),(193,137,NULL,0,'','','','045/7635102','','amministrazione@bonvicini.eu','','',''),(194,138,NULL,0,'Lorenzo','','','','388/3450482','marronecrea@yahoo.it','','',''),(195,139,NULL,2,'Silvana','Kulla (proprietaria)','','','','silvana@si-mac.it','','',''),(196,140,NULL,1,'Claudio','Sterpi (proprietario)','','0131/897900','','info@derthonaserramenti.it','','',''),(197,141,NULL,1,'Giovanni','Bagnulo','','','','giovanni.bagnulo@gmail.com','','',''),(198,143,NULL,0,'','','','071/67778','','info@sarasrl.net','','',''),(199,145,NULL,1,'Fabrizio','Pollastri','','059/8860104','338/4388395','info@plastgroup.it','','',''),(200,146,NULL,1,'Daniele','','','06/9073385','349/8504076','rikedo.amministrazione@gmail.com','','',''),(201,147,NULL,0,'','','','0541/693399','','info@gt-propellers.com','','',''),(202,148,NULL,0,'','Piccari','','0722/362643','339/6731563','piccariadriano@libero.it','','',''),(203,149,NULL,2,'Olga','Llamas','','','','ollamas@scmgroup.com','','',''),(204,149,NULL,1,'Michele','Prandolini','','','','michele.prandolini@scmgroup.com','','',''),(205,151,NULL,0,'','','','0541/750046','','artigianidellegnosrl@gmail.com','','',''),(206,152,NULL,0,'Roberto','Mannelli','','0577/684269','','roberto.mannelli@noidellanotte.it','','',''),(207,153,NULL,1,'Jacopo','delli Carri','','','','jacopo.dellicarri@scmgroup.com','','',''),(208,154,NULL,1,'Paolo','Rudon','','0423/755375','333/1703766','info@domus-artis.it','','',''),(209,66,NULL,0,'Centralino','','','0577/632811','','','','',''),(210,155,NULL,1,'Matteo','Toti','','0583/23430','333/1259083','matteo.toti@gruppocamarlinghi.it','','',''),(211,156,NULL,1,'Denis','Lucchetta','','','349/8095574','denis.luchetta@essepi.it','','',''),(212,157,NULL,2,'Marta','De Giorgi','','0172/474073','','m.degiorgi@ferwoodgroup.com','','',''),(213,158,NULL,1,'Gabriele','Del Fabbro','','0433/72068','333/2773609','info@delfabbroprimo.it','','',''),(214,159,NULL,1,'Danilo','','','0431/56145','','danilo@bminfissi.it','','',''),(215,160,NULL,NULL,'','','','','','','','',''),(216,159,NULL,2,'Sara','Vignotto','','','','amministrazione@bminfissi.it','','',''),(217,161,NULL,1,'Antonio','Fosso','','','','a.fosso@fossoallestimenti.it','','',''),(218,162,NULL,1,'Federico','','','0574/1586159','','f.palmieri@isopad.sogimi.com','','',''),(219,163,NULL,0,'','','','0422/978170','','falegnameriamg@gmail.com','','',''),(220,164,NULL,1,'Michele Fattori','','','','','alfa_tech@virgilio.it','','',''),(221,165,NULL,1,'Roberto','Fontana','','','','','','',''),(222,166,NULL,1,'Carmine','','','','','attrezzeria@3ellen.it','','',''),(223,167,NULL,0,'','','','0481/90094','','','','',''),(224,53,NULL,0,'','','','','','info@mit-srl.com','','',''),(225,168,NULL,0,'Amministrazione Marco','Palombini','','071/7506030','','amm1@luiporte.it','','',''),(226,168,NULL,1,'Paolo','Mariani','','','','p.mariani@luiporte.it','','',''),(227,169,NULL,1,'Gabriele','Venturelli','','0722/3119110','338/3648547','gabriele.venturelli@p-v.net','','',''),(228,170,NULL,1,'Gianni','Vada','','','','gianni@falegnameriavadi.it','','',''),(229,170,NULL,0,'','','','','','info@falegnameriavadi.it','','',''),(230,171,NULL,1,'Luigi','','','347/2515442','','info.agathis@gmail.com','','',''),(231,172,NULL,0,'','','','','','info@trendpropostedarredo.it','','',''),(232,62,NULL,0,'','','','045/7401239','','','','',''),(233,173,NULL,0,'Luca','De Angelis','','06/7197077','388/1282014','pdsrl@pdporteblindate.com','','',''),(234,174,NULL,0,'Vito','Castellana','','','342/7665766','tecnico@ebane.it','','',''),(235,176,NULL,0,'','','','0424/540655','','info@bsporte.it','','',''),(236,175,NULL,0,'','','','','','sergio.scapin68@gmail.com','','',''),(237,177,NULL,2,'Laura','Antinori','','071/7950538','','laura.antinori@reamarine.com','','',''),(238,178,NULL,0,'','','','349/7487241','','','','',''),(239,179,NULL,0,'','Barilari','','','348/0947727','barilari@neomec.it','','',''),(240,180,NULL,0,'','Tassini','','06/9086670','','tassini@tassinionline.it','','',''),(241,77,NULL,1,'Ivano','','','','','info@bimalsrl.com','','',''),(242,181,NULL,0,'Aldo','Tudisco','','','340/2473471','info@fabrikalegno.com','','',''),(243,179,NULL,0,'Paola','Fraticelli','','0721/200113','','segreteria@neomec.it','','',''),(244,182,NULL,1,'Gianni','Re','','','380/4595335','arredarefalegnameria@gmail.com','','',''),(245,21,NULL,1,'Matteo','Villa','','','','mvilla@scmgroup.com','','',''),(246,184,NULL,2,'Maurizia','Nanni','','','','vidafcsrl@gmail.com','','',''),(247,185,NULL,1,'Corrado (titolare)','Nucci','','0541/931173','339/6214671','corrado.nucci@faitadriatica.it','','',''),(248,186,NULL,1,'Bettoli','Enrico','','','335/7143783','','','',''),(249,187,NULL,1,'Maurizio','','','0577/370222','338/3603131','legnoinfissi@virgilio.it','','',''),(250,188,NULL,1,'Franco','Barriviera','','','','info@puntob.it','','',''),(251,189,NULL,0,'','','','0541/933207','','info.idealegnosas@gmail.com','','',''),(252,189,NULL,0,'','','','','','amministrazione.idealegnosas@gmail.com','','',''),(253,27,NULL,1,'Bastiano','','','','392/9708407','operas.srls@gmail.com','','',''),(254,190,NULL,1,'Daniele','Truglio','','085 850 9335','','produzione@patriarcagroup.it','','',''),(255,191,NULL,1,'Pierino','Valentino','','','338/9414532','centroitaliaserramenti@gmail.com','','',''),(256,192,NULL,1,'Simone','','','0547/671840','','vuessearredi@gmail.com','','',''),(257,193,NULL,3,'Roberta','Fusa','','0444/557457','','roberta@falegnameriafusa.it','','',''),(258,193,NULL,0,'','','','','','info@falegnameriafusa.it','','',''),(259,194,NULL,0,'','','','0549/900315','','cstranciati@omniway.sm','','',''),(260,111,NULL,1,'Andrea','Mondino','','','','andrea@utensillegno.cn.it','','',''),(261,195,NULL,1,'Luca','','','0543/494056','335/7563999','info@colangeloarredamenti.com','','',''),(262,196,NULL,1,'Alberto','Cordiani','','3492387355','','cordianialberto@gmail.com','','',''),(263,196,NULL,1,'Alessio','Cordiani','','','','cordianialessio@gmail.com','','',''),(264,197,NULL,1,'Leonardo','Pistillo','','','348/4003784','bioclima.sm@gmail.com','','',''),(265,198,NULL,1,'Esterino','Ceria','','','','esterinoceria@gmail.com','','',''),(266,199,NULL,1,'Marcello','Marelli','','','','marcellomarelli74@gmail.com','','',''),(267,200,NULL,1,'Fabio','Formenti','','','','info@formentigroup.it','','',''),(268,201,NULL,1,'','','','','','produzione@centroserramento.it','','',''),(269,202,NULL,2,'Angela','Addazii','','','3280432495','angelaa@produzionedesign.it','','',''),(270,203,NULL,1,'Antonio','Lepore','','0881/063004','328/0192466','salsrl.serramenti@gmail.com','','',''),(271,204,NULL,1,'Maurizio','Marroni','','','348/5824788','maurizio.marroni@italcomsrl.it','','',''),(272,204,NULL,0,'','','','','','info@neoon.it','','',''),(273,199,NULL,1,'Martino','Marelli','','','','martinomarelli76@gmail.com','','',''),(274,205,NULL,7,'','','','','','acquisti@mlsrl.bo.it','','',''),(275,206,NULL,0,'','','','0836/234580','','terence@terotecna.it','','',''),(276,206,NULL,0,'','','','','','amerigo@terotecna.it','','',''),(277,206,NULL,0,'','','','','','franco@terotecna.it','','',''),(278,207,NULL,0,'','','','075/3740952','','info@expodesignsrl.it','','',''),(279,207,NULL,1,'Gabriele','Regi','','','','gabriele@expodesignsrl.it','','',''),(280,208,NULL,1,'Luca','Valentini','','071/7222270','340/8069151','luca@fevalmobili.it','','',''),(281,208,NULL,0,'','','','','','info@fevalmobili.it','','',''),(282,209,NULL,1,'Luca','D\'Alessio','','','334/8400445','info@arredogamma.com','','',''),(283,210,NULL,1,'Marco','Tebaldi','','051/851600','','m.tebaldi@tecoarredamenti.com','','',''),(284,211,NULL,1,'Matteo','Cattaneo','','','333/3446635','falegnameriacattaneo@alice.it','','',''),(285,212,NULL,1,'Andrea','Bianchi','','0541/964522','328/3778105','info@spazioscale.it','','',''),(286,213,NULL,3,'Antonella','','','0828/437198','','lsg.srl2016@gmail.com','','',''),(287,215,NULL,1,'Gabriele','Baldini','','','348/6056112','legnoartesrl70@tiscali.it','','',''),(288,216,NULL,1,'Andrea','Manconi','','','','andrea.manconi@scmgroup.com','','',''),(289,216,NULL,0,'Aministrazione','','','','','facturen@scmgroup.nl','','',''),(290,218,NULL,1,'Sergio','Tieppo','','','349/8127677','info@albotegon.com','','',''),(291,219,NULL,0,'','','','0442/88365','348/2900741','info@bordiniarredamenti.it','','',''),(292,220,NULL,1,'Pasquale','Moscaritolo','','0577/704227','339/1826948','gmimballaggi@yahoo.it','','',''),(293,221,NULL,0,'Federica','','','049/9550038','','info@errebilegno.it','','',''),(294,222,NULL,0,'','','','0377/32240','','info@koropack.com','','',''),(295,223,NULL,2,'Roberta','Volpi','','0759/412062','338/9646965','volpifalegnameria@libero.it','','',''),(296,224,NULL,1,'Giovanni','Greco','','','327/5415846','giovanni_greco@hotmail.it','','',''),(297,226,NULL,1,'Alf','Kermer','','','','akermer@scmgroup.com','','',''),(298,227,NULL,1,'Tiziano','Favalli','','030/962453','334/3404091','tizianofavalli1964@gmail.com','','',''),(299,228,NULL,1,'Damiano','Roncato','','041/440105','','damiano.roncato@roncato.net','','',''),(300,228,NULL,0,'','','','','','segreteria@roncato.net','','',''),(301,229,NULL,1,'Cristian','','','049/5082518','340/9384782','flamarlegno@gmail.com','','',''),(302,229,NULL,1,'Matteo','','','','345/7969940','','','',''),(303,230,NULL,0,'','','','','','ordini@illuminotecnica-cesena.com','','',''),(304,231,NULL,0,'Eliona','','','','','lonaneb@gmail.com','','',''),(305,232,NULL,0,'','','','0742/98876','','info@biondini.it','','',''),(306,233,NULL,1,'Alfredo','Barba','','','3356530453','','','','');
/*!40000 ALTER TABLE `tbcontatti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbmodalitapagamento`
--

DROP TABLE IF EXISTS `tbmodalitapagamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbmodalitapagamento` (
  `idModalitaPagamento` int(11) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(100) NOT NULL,
  PRIMARY KEY (`idModalitaPagamento`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbmodalitapagamento`
--

LOCK TABLES `tbmodalitapagamento` WRITE;
/*!40000 ALTER TABLE `tbmodalitapagamento` DISABLE KEYS */;
INSERT INTO `tbmodalitapagamento` (`idModalitaPagamento`, `Nome`) VALUES (1,'Assegno'),(2,'Bonifico bancario'),(3,'Carta di credito'),(4,'Contanti'),(5,'Bancomat'),(6,'Modulo F24'),(7,'Effetti/Utenze'),(8,'Carta prepagata');
/*!40000 ALTER TABLE `tbmodalitapagamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbtipopagamento`
--

DROP TABLE IF EXISTS `tbtipopagamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbtipopagamento` (
  `idTipoPagamento` int(11) NOT NULL AUTO_INCREMENT,
  `descrizione` varchar(200) NOT NULL,
  `DataRifScad` varchar(50) NOT NULL,
  `GiorniDataRif` int(11) NOT NULL,
  `GiornoAddebito` int(11) NOT NULL,
  PRIMARY KEY (`idTipoPagamento`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbtipopagamento`
--

LOCK TABLES `tbtipopagamento` WRITE;
/*!40000 ALTER TABLE `tbtipopagamento` DISABLE KEYS */;
INSERT INTO `tbtipopagamento` (`idTipoPagamento`, `descrizione`, `DataRifScad`, `GiorniDataRif`, `GiornoAddebito`) VALUES (6,'Contanti','DF - data fattura',0,0),(7,'Bonifico 30 gg D.F.','DF - data fattura',30,0),(8,'Carta di credito','DF - data fattura',0,0),(11,'Bonifico 60 gg F.M.','FM - Fine mese',60,0),(13,'Bonifico bancario','DF - data fattura',0,0),(14,'Pagato','DF - data fattura',0,0),(18,'Rimessa Diretta','DF - data fattura',0,0),(19,'SWIFT internazionale','DF - data fattura',0,0),(21,'Bonifico 60 gg D.F.','DF - data fattura',60,0),(22,'Bonifico 30 gg F.M.','FM - Fine mese',30,0),(23,'RI.BA. 60gg F.M.','FM - Fine mese',60,0),(24,'Modulo F24','DF - data fattura',0,0),(25,'RI.BA. 30gg F.M.','FM - Fine mese',30,0),(26,'RI.BA. 90gg F.M.','FM - Fine mese',90,0),(27,'Bonifico 90 gg D.F.','DF - data fattura',90,0),(28,'RI.BA. 120gg F.M.','FM - Fine mese',120,0),(29,'Bank Transfer','DF - data fattura',0,0),(30,'50% Fine lavori - 50% Bonifico 30 FM','FM - Fine mese',30,0),(31,'Assegno a fine lavori','DF - data fattura',0,0),(32,'Assegno','DF - data fattura',0,0),(33,'RI.BA. 30gg F.M. scad. 10','FM - Fine mese',30,10),(34,'RI.BA. 30gg F.M. scad. 5','FM - Fine mese',30,5),(35,'Ri.Ba. 60gg FM','FM - Fine mese',60,0);
/*!40000 ALTER TABLE `tbtipopagamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbunitamisura`
--

DROP TABLE IF EXISTS `tbunitamisura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbunitamisura` (
  `idUnitaMisura` int(11) NOT NULL AUTO_INCREMENT,
  `denominazione` varchar(50) NOT NULL,
  `denominazione_stampa` varchar(100) DEFAULT NULL,
  `stato_attivo` tinyint(1) NOT NULL,
  `creato_il` datetime(6) DEFAULT NULL,
  `modificato_il` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`idUnitaMisura`),
  KEY `tbUnitaMisu_denomin_991c5d_idx` (`denominazione`),
  KEY `tbUnitaMisu_stato_a_9a0539_idx` (`stato_attivo`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbunitamisura`
--

LOCK TABLES `tbunitamisura` WRITE;
/*!40000 ALTER TABLE `tbunitamisura` DISABLE KEYS */;
INSERT INTO `tbunitamisura` (`idUnitaMisura`, `denominazione`, `denominazione_stampa`, `stato_attivo`, `creato_il`, `modificato_il`) VALUES (1,'Num.','Num.',1,'2025-12-20 13:59:21.798804','2025-12-20 13:59:21.798828'),(2,'km','per Chilometro - per kilometer',1,'2025-12-20 13:59:21.799666','2025-12-20 13:59:21.799679'),(3,'gg','per Giornata - per Day',1,'2025-12-20 13:59:21.800584','2025-12-20 13:59:21.800596'),(4,'Ore','per Ora o frazione',1,'2025-12-20 13:59:21.801780','2025-12-20 13:59:21.801793'),(5,'Kg','Kg',1,'2025-12-20 13:59:21.802847','2025-12-20 13:59:21.802861'),(7,'Day','Daily',1,'2025-12-20 13:59:21.803698','2025-12-20 13:59:21.803710'),(8,'Hour','Hour or fraction',1,'2025-12-20 13:59:21.805234','2025-12-20 13:59:21.805247'),(9,'Pz','Pezzi',1,'2025-12-20 13:59:21.806032','2025-12-20 13:59:21.806042'),(10,'Lt','Litri',1,'2025-12-20 13:59:21.806790','2025-12-20 13:59:21.806800'),(11,'Mt','Metri',1,'2025-12-20 13:59:21.807751','2025-12-20 13:59:21.807764'),(12,'Set','Set oppure Kit',1,'2025-12-20 13:59:21.808626','2025-12-20 13:59:21.808639'),(13,'Coppia','Coppia',1,'2025-12-20 13:59:21.809661','2025-12-20 13:59:21.809672'),(14,'Conf','Confezione',1,'2025-12-20 13:59:21.810560','2025-12-20 13:59:21.810570');
/*!40000 ALTER TABLE `tbunitamisura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'GMR'
--

--
-- Dumping routines for database 'GMR'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-23 23:31:46
